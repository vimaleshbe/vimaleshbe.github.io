import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";

import * as portfolioDataModule from "@/lib/usePortfolioData";
import Home from "@/pages/index";

type MotionDivProps = React.HTMLAttributes<HTMLDivElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  animate?: unknown;
  transition?: unknown;
};

type MotionAsideProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  animate?: unknown;
  transition?: unknown;
};

type MotionArticleProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  whileInView?: unknown;
  viewport?: unknown;
  transition?: unknown;
};

jest.mock("framer-motion", () => ({
  motion: {
    div: (props: MotionDivProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.animate;
      delete rest.transition;

      return <div {...rest}>{children}</div>;
    },
    aside: (props: MotionAsideProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.animate;
      delete rest.transition;

      return <aside {...rest}>{children}</aside>;
    },
    article: (props: MotionArticleProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.whileInView;
      delete rest.viewport;
      delete rest.transition;

      return <article {...rest}>{children}</article>;
    },
  },
  useReducedMotion: () => false,
}));

describe("Home page", () => {
  it("renders the composed portfolio flow from normalized data", () => {
    const queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
        },
      },
    });

    render(
      <QueryClientProvider client={queryClient}>
        <Home />
      </QueryClientProvider>,
    );

    expect(screen.getByRole("link", { name: "Intro" })).toBeInTheDocument();
    expect(screen.getByText(/Vimalesh Jeyavelmani/i)).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /activate light theme/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", {
        name: /Sample Agentic Orchestration Platform/i,
      }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: /Associate Architect/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: /GitHub Copilot/i }),
    ).toBeInTheDocument();
  });

  it("returns null when no portfolio data is available", () => {
    const queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
        },
      },
    });

    const usePortfolioDataSpy = jest.spyOn(
      portfolioDataModule,
      "usePortfolioData",
    );
    usePortfolioDataSpy.mockReturnValue({
      data: undefined,
    } as unknown as ReturnType<typeof portfolioDataModule.usePortfolioData>);

    const { container } = render(
      <QueryClientProvider client={queryClient}>
        <Home />
      </QueryClientProvider>,
    );

    expect(container).toBeEmptyDOMElement();

    usePortfolioDataSpy.mockRestore();
  });
});
