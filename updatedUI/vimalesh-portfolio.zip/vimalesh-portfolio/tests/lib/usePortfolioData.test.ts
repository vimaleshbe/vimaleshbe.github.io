import {
  getPortfolioData,
  normalizeExperience,
  normalizeSkillCategory,
  normalizeSocialLinks,
} from "@/lib/usePortfolioData";

describe("usePortfolioData normalization", () => {
  it("maps raw skill categories into canonical display domains", () => {
    expect(normalizeSkillCategory("Frontend Engineering")).toBe("frontend");
    expect(normalizeSkillCategory("Backend APIs")).toBe("backend");
    expect(normalizeSkillCategory("AI & Agentic Orchestration")).toBe(
      "ai-agents",
    );
    expect(normalizeSkillCategory("Cloud & DevOps")).toBe("cloud");
    expect(normalizeSkillCategory("Programming Languages")).toBe("supporting");
  });

  it("normalizes social links with a mailto href", () => {
    expect(
      normalizeSocialLinks({
        github: "",
        linkedin: "https://linkedin.com/in/example",
        email: "vimalesh@example.com",
      }),
    ).toEqual({
      github: undefined,
      linkedin: "https://linkedin.com/in/example",
      email: "vimalesh@example.com",
      mailtoHref: "mailto:vimalesh@example.com",
    });
  });

  it("marks the present role as current in the timeline", () => {
    const normalized = normalizeExperience([
      {
        company: "Example",
        position: "Engineer",
        duration: "2020 - 2021",
        description: "Built features.",
      },
      {
        company: "Example",
        position: "Architect",
        duration: "2021 - Present",
        description: "Leads systems.",
      },
    ]);

    expect(normalized[1]?.isCurrentRole).toBe(true);
    expect(normalized[0]?.timelineOrder).toBe(1);
    expect(normalized[1]?.timelineOrder).toBe(0);
  });

  it("returns normalized portfolio data from local JSON sources", () => {
    const data = getPortfolioData();

    expect(data.personal.name).toContain("Vimalesh");
    expect(data.skillDomains.length).toBeGreaterThan(0);
    expect(data.projects.length).toBeGreaterThan(0);
    expect(data.social.mailtoHref).toBe(`mailto:${data.social.email}`);
    expect(data.theme.dark.primaryColor).toBeTruthy();
    expect(data.theme.light.backgroundColor).toBeTruthy();
  });
});
