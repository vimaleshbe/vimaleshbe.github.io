import { render, screen } from "@testing-library/react";

type MotionArticleProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  whileInView?: unknown;
  viewport?: unknown;
  transition?: unknown;
};

jest.mock("framer-motion", () => ({
  motion: {
    article: (props: MotionArticleProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.whileInView;
      delete rest.viewport;
      delete rest.transition;

      return <article {...rest}>{children}</article>;
    },
  },
  useReducedMotion: jest.fn(() => false),
}));

import { Experience } from "@/components/Experience";

const mockedUseReducedMotion = jest.requireMock("framer-motion")
  .useReducedMotion as jest.Mock;

describe("Experience", () => {
  it("renders grouped company timeline content and current role badge", () => {
    render(
      <Experience
        experience={[
          {
            company: "EY",
            position: "Technical Lead",
            duration: "2020 - 2022",
            description: "Built systems.",
            timelineOrder: 0,
            isCurrentRole: false,
          },
          {
            company: "EY",
            position: "Associate Architect",
            duration: "2024 - Present",
            description: "Leads architecture.",
            timelineOrder: 1,
            isCurrentRole: true,
          },
        ]}
      />,
    );

    expect(screen.getByText("Associate Architect")).toBeInTheDocument();
    expect(screen.getByText("Current")).toBeInTheDocument();
    expect(screen.getByText("EY")).toBeInTheDocument();
    expect(screen.getByText(/2 roles/i)).toBeInTheDocument();
    expect(screen.queryByText(/Timeline marker/i)).not.toBeInTheDocument();
  });

  it("renders experience with reduced motion enabled", () => {
    mockedUseReducedMotion.mockReturnValue(true);

    render(
      <Experience
        experience={[
          {
            company: "EY",
            position: "Associate Architect",
            duration: "2024 - Present",
            description: "Leads architecture.",
            timelineOrder: 1,
            isCurrentRole: true,
          },
        ]}
      />,
    );

    expect(screen.getByText("Associate Architect")).toBeInTheDocument();
    mockedUseReducedMotion.mockReturnValue(false);
  });
});
