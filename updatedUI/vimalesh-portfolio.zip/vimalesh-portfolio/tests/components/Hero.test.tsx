import { render, screen } from "@testing-library/react";

type MotionDivProps = React.HTMLAttributes<HTMLDivElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  animate?: unknown;
  transition?: unknown;
};

type MotionAsideProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  animate?: unknown;
  transition?: unknown;
};

jest.mock("framer-motion", () => ({
  motion: {
    div: (props: MotionDivProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.animate;
      delete rest.transition;

      return <div {...rest}>{children}</div>;
    },
    aside: (props: MotionAsideProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.animate;
      delete rest.transition;

      return <aside {...rest}>{children}</aside>;
    },
  },
  useReducedMotion: jest.fn(() => false),
}));

import { Hero } from "@/components/Hero";

const mockedUseReducedMotion = jest.requireMock("framer-motion")
  .useReducedMotion as jest.Mock;

const theme = {
  primaryColor: "#38bdf8",
  secondaryColor: "#0f172a",
  accentColor: "#fbbf24",
  backgroundColor: "#020617",
  surfaceColor: "rgba(15, 23, 42, 0.78)",
  surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
  textColor: "#e2e8f0",
  textMutedColor: "#94a3b8",
  borderColor: "rgba(148, 163, 184, 0.22)",
  separatorColor: "rgba(56, 189, 248, 0.26)",
  navbarColor: "rgba(2, 6, 23, 0.88)",
};

describe("Hero", () => {
  it("renders personal profile content without the removed hero actions", () => {
    render(
      <Hero
        personal={{
          name: "Vimalesh Jeyavelmani",
          title: "AI Solutions Architect",
          tagline: "Building with orchestration-first systems.",
          bio: "Biography content",
          profilePhoto: "img/profile.jpg",
          location: "Chennai",
          email: "vimalesh@example.com",
        }}
        theme={theme}
      />,
    );

    expect(screen.getByText("Vimalesh Jeyavelmani")).toBeInTheDocument();
    expect(screen.getByAltText(/profile/i)).toBeInTheDocument();
    expect(
      screen.getByText(/Years in architecture and data engineering/i),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Core domains across AI, cloud, backend, frontend/i),
    ).toBeInTheDocument();
    expect(screen.queryByText(/Portfolio 2026/i)).not.toBeInTheDocument();
    expect(
      screen.queryByRole("link", { name: "Explore Projects" }),
    ).not.toBeInTheDocument();
  });

  it("renders the hero with reduced motion enabled", () => {
    mockedUseReducedMotion.mockReturnValue(true);

    render(
      <Hero
        personal={{
          name: "Vimalesh Jeyavelmani",
          title: "AI Solutions Architect",
          tagline: "Building with orchestration-first systems.",
          bio: "Biography content",
          profilePhoto: "img/profile.jpg",
          location: "Chennai",
          email: "vimalesh@example.com",
        }}
        theme={theme}
      />,
    );

    expect(screen.getByText(/Current focus/i)).toBeInTheDocument();
    mockedUseReducedMotion.mockReturnValue(false);
  });
});
