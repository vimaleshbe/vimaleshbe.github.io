import { render, screen } from "@testing-library/react";

import { Navbar } from "@/components/Navbar";

const theme = {
  primaryColor: "#38bdf8",
  secondaryColor: "#0f172a",
  accentColor: "#fbbf24",
  backgroundColor: "#020617",
  surfaceColor: "rgba(15, 23, 42, 0.78)",
  surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
  textColor: "#e2e8f0",
  textMutedColor: "#94a3b8",
  borderColor: "rgba(148, 163, 184, 0.22)",
  separatorColor: "rgba(56, 189, 248, 0.26)",
  navbarColor: "rgba(2, 6, 23, 0.88)",
};

describe("Navbar", () => {
  it("renders anchor navigation and social actions", () => {
    render(
      <Navbar
        social={{
          github: "https://github.com/example",
          linkedin: "https://linkedin.com/in/example",
          email: "vimalesh@example.com",
          mailtoHref: "mailto:vimalesh@example.com",
        }}
        themeMode="dark"
        onToggleTheme={jest.fn()}
        theme={theme}
      />,
    );

    expect(screen.getByRole("link", { name: "Intro" })).toHaveAttribute(
      "href",
      "#hero",
    );
    expect(screen.getByRole("link", { name: "GitHub" })).toHaveAttribute(
      "href",
      "https://github.com/example",
    );
    expect(screen.getByRole("link", { name: "Email" })).toHaveAttribute(
      "href",
      "mailto:vimalesh@example.com",
    );
    expect(
      screen.getByRole("button", { name: /activate light theme/i }),
    ).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "LinkedIn" })).toHaveAttribute(
      "href",
      "https://linkedin.com/in/example",
    );
  });

  it("omits optional social links when they are unavailable", () => {
    render(
      <Navbar
        social={{
          email: "vimalesh@example.com",
          mailtoHref: "mailto:vimalesh@example.com",
        }}
        themeMode="light"
        onToggleTheme={jest.fn()}
        theme={theme}
      />,
    );

    expect(
      screen.queryByRole("link", { name: "GitHub" }),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByRole("link", { name: "LinkedIn" }),
    ).not.toBeInTheDocument();
  });
});
