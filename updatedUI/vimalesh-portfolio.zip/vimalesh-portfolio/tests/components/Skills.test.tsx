import { render, screen } from "@testing-library/react";

type MotionArticleProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  whileInView?: unknown;
  viewport?: unknown;
  transition?: unknown;
};

jest.mock("framer-motion", () => ({
  motion: {
    article: (props: MotionArticleProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.whileInView;
      delete rest.viewport;
      delete rest.transition;

      return <article {...rest}>{children}</article>;
    },
  },
  useReducedMotion: jest.fn(() => false),
}));

import { Skills } from "@/components/Skills";

const mockedUseReducedMotion = jest.requireMock("framer-motion")
  .useReducedMotion as jest.Mock;

const theme = {
  primaryColor: "#38bdf8",
  secondaryColor: "#0f172a",
  accentColor: "#fbbf24",
  backgroundColor: "#020617",
  surfaceColor: "rgba(15, 23, 42, 0.78)",
  surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
  textColor: "#e2e8f0",
  textMutedColor: "#94a3b8",
  borderColor: "rgba(148, 163, 184, 0.22)",
  separatorColor: "rgba(56, 189, 248, 0.26)",
  navbarColor: "rgba(2, 6, 23, 0.88)",
};

describe("Skills", () => {
  it("renders grouped skills and fallback domains", () => {
    render(
      <Skills
        skillDomains={[
          {
            category: "AI & Agentic Orchestration",
            technologies: ["AutoGen", "MCP"],
            displayDomain: "ai-agents",
            accentStyle: "from-amber-300/35 via-orange-300/10 to-transparent",
          },
          {
            category: "Programming Languages",
            technologies: ["TypeScript"],
            displayDomain: "supporting",
            accentStyle: "from-stone-400/25 via-zinc-300/10 to-transparent",
          },
        ]}
        theme={theme}
      />,
    );

    expect(screen.getByText("AI + Agentic Orchestration")).toBeInTheDocument();
    expect(screen.getByText("Supporting Stack")).toBeInTheDocument();
    expect(screen.getByText("TypeScript")).toBeInTheDocument();
  });

  it("renders skills with reduced motion enabled", () => {
    mockedUseReducedMotion.mockReturnValue(true);

    render(
      <Skills
        skillDomains={[
          {
            category: "AI & Agentic Orchestration",
            technologies: ["AutoGen", "MCP"],
            displayDomain: "ai-agents",
            accentStyle: "from-amber-300/35 via-orange-300/10 to-transparent",
          },
        ]}
        theme={theme}
      />,
    );

    expect(screen.getByText("AI + Agentic Orchestration")).toBeInTheDocument();
    mockedUseReducedMotion.mockReturnValue(false);
  });
});
