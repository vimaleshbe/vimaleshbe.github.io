import { render, screen } from "@testing-library/react";

import { Certifications } from "@/components/Certifications";

const theme = {
  primaryColor: "#38bdf8",
  secondaryColor: "#0f172a",
  accentColor: "#fbbf24",
  backgroundColor: "#020617",
  surfaceColor: "rgba(15, 23, 42, 0.78)",
  surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
  textColor: "#e2e8f0",
  textMutedColor: "#94a3b8",
  borderColor: "rgba(148, 163, 184, 0.22)",
  separatorColor: "rgba(56, 189, 248, 0.26)",
  navbarColor: "rgba(2, 6, 23, 0.88)",
};

type MotionArticleProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  whileInView?: unknown;
  viewport?: unknown;
  transition?: unknown;
};

jest.mock("framer-motion", () => ({
  motion: {
    article: (props: MotionArticleProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.whileInView;
      delete rest.viewport;
      delete rest.transition;

      return <article {...rest}>{children}</article>;
    },
  },
  useReducedMotion: jest.fn(() => false),
}));

const mockedUseReducedMotion = jest.requireMock("framer-motion")
  .useReducedMotion as jest.Mock;

describe("Certifications", () => {
  it("renders certification verification links conditionally", () => {
    render(
      <Certifications
        certifications={[
          {
            name: "GitHub Copilot",
            issuer: "GitHub",
            date: "2025",
            credentialId: "123",
            verificationUrl: "https://example.com/verify",
            description: "Description",
          },
          {
            name: "Internal Badge",
            issuer: "EY",
            date: "2024",
            credentialId: "456",
            description: "Description",
          },
        ]}
        theme={theme}
      />,
    );

    expect(
      screen.getByRole("link", { name: "Verify credential" }),
    ).toHaveAttribute("href", "https://example.com/verify");
    expect(
      screen.getByText("Verification available on request"),
    ).toBeInTheDocument();
  });

  it("renders certifications with reduced motion enabled", () => {
    mockedUseReducedMotion.mockReturnValue(true);

    render(
      <Certifications
        certifications={[
          {
            name: "Internal Badge",
            issuer: "EY",
            date: "2024",
            credentialId: "456",
            description: "Description",
          },
        ]}
        theme={theme}
      />,
    );

    expect(screen.getByText("Internal Badge")).toBeInTheDocument();
    mockedUseReducedMotion.mockReturnValue(false);
  });
});
