import { render, screen } from "@testing-library/react";

import { Projects } from "@/components/Projects";

const theme = {
  primaryColor: "#38bdf8",
  secondaryColor: "#0f172a",
  accentColor: "#fbbf24",
  backgroundColor: "#020617",
  surfaceColor: "rgba(15, 23, 42, 0.78)",
  surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
  textColor: "#e2e8f0",
  textMutedColor: "#94a3b8",
  borderColor: "rgba(148, 163, 184, 0.22)",
  separatorColor: "rgba(56, 189, 248, 0.26)",
  navbarColor: "rgba(2, 6, 23, 0.88)",
};

type MotionArticleProps = React.HTMLAttributes<HTMLElement> & {
  children?: React.ReactNode;
  initial?: unknown;
  whileInView?: unknown;
  viewport?: unknown;
  transition?: unknown;
};

jest.mock("framer-motion", () => ({
  motion: {
    article: (props: MotionArticleProps) => {
      const { children, ...rest } = props;
      delete rest.initial;
      delete rest.whileInView;
      delete rest.viewport;
      delete rest.transition;

      return <article {...rest}>{children}</article>;
    },
  },
  useReducedMotion: () => false,
}));

describe("Projects", () => {
  it("renders project content and hides missing optional links", () => {
    render(
      <Projects
        projects={[
          {
            slug: "agentic-platform",
            name: "Agentic Platform",
            summary: "Summary",
            description: "Description",
            status: "In Progress",
            year: "2026",
            tags: ["AI"],
            links: {
              repository: "",
              demo: "",
              caseStudy: "",
            },
            featured: true,
          },
        ]}
        theme={theme}
      />,
    );

    expect(screen.getByText("Agentic Platform")).toBeInTheDocument();
    expect(
      screen.getByText(/Project links will be published/i),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole("link", { name: "Repository" }),
    ).not.toBeInTheDocument();
  });

  it("renders available project actions when links are present", () => {
    render(
      <Projects
        projects={[
          {
            slug: "agentic-platform",
            name: "Agentic Platform",
            summary: "Summary",
            description: "Description",
            status: "In Progress",
            year: "2026",
            tags: ["AI"],
            links: {
              repository: "https://github.com/example/repo",
              demo: "https://example.com/demo",
              caseStudy: "https://example.com/case-study",
            },
            featured: false,
          },
        ]}
        theme={theme}
      />,
    );

    expect(screen.getByRole("link", { name: "Repository" })).toHaveAttribute(
      "href",
      "https://github.com/example/repo",
    );
    expect(screen.getByRole("link", { name: "Live demo" })).toHaveAttribute(
      "href",
      "https://example.com/demo",
    );
    expect(screen.getByRole("link", { name: "Case study" })).toHaveAttribute(
      "href",
      "https://example.com/case-study",
    );
  });
});
