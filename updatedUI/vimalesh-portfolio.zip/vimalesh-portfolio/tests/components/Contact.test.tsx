import { render, screen } from "@testing-library/react";

import { Contact } from "@/components/Contact";

const theme = {
  primaryColor: "#38bdf8",
  textColor: "#e2e8f0",
  textMutedColor: "#94a3b8",
  borderColor: "rgba(148, 163, 184, 0.22)",
  surfaceColor: "rgba(15, 23, 42, 0.78)",
  surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
};

describe("Contact", () => {
  it("renders contact actions including a mailto link", () => {
    render(
      <Contact
        social={{
          github: "https://github.com/example",
          linkedin: "https://linkedin.com/in/example",
          email: "vimalesh@example.com",
          mailtoHref: "mailto:vimalesh@example.com",
        }}
        theme={theme}
      />,
    );

    expect(screen.getByRole("link", { name: "GitHub" })).toHaveAttribute(
      "href",
      "https://github.com/example",
    );
    expect(screen.getByRole("link", { name: "Email" })).toHaveAttribute(
      "href",
      "mailto:vimalesh@example.com",
    );
  });

  it("omits unavailable optional contact actions", () => {
    render(
      <Contact
        social={{
          email: "vimalesh@example.com",
          mailtoHref: "mailto:vimalesh@example.com",
        }}
        theme={theme}
      />,
    );

    expect(
      screen.queryByRole("link", { name: "GitHub" }),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByRole("link", { name: "LinkedIn" }),
    ).not.toBeInTheDocument();
  });
});
