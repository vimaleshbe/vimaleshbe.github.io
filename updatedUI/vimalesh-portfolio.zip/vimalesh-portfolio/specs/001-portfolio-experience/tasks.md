# Tasks: Portfolio Experience

**Input**: Design documents from `/specs/001-portfolio-experience/`

**Prerequisites**: plan.md (required), spec.md (required for user stories), research.md, data-model.md, contracts/

**Tests**: Jest-based unit tests are required for each section component, the shared data-loading layer, navbar interaction behavior, and the composed homepage flow. The implementation must enforce a minimum 85% overall code coverage threshold.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., [US1], [US2], [US3])
- Include exact file paths in descriptions

## Path Conventions

- **Single project**: `src/`, `tests/` at repository root
- Paths below follow the current single-project Next.js repository layout

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Align the existing repository with the planned portfolio architecture and deployment requirements

- [x] T001 Audit the existing Next.js Pages Router scaffold in `src/pages/`, `src/styles/`, `package.json`, and `next.config.ts` against the implementation plan
- [x] T002 Update static hosting configuration in `next.config.ts` for GitHub Pages export with `output: 'export'` and `images: { unoptimized: true }`
- [x] T003 [P] Add the required frontend dependencies for TanStack Query and Framer Motion in `package.json`
- [x] T004 [P] Prepare the component, data, type, and test directory structure in `src/components/`, `src/lib/`, `src/types/`, and `tests/`
- [x] T005 [P] Add and configure the Jest unit test stack plus 85% coverage thresholds in `package.json` and the required Jest configuration files
  - [x] T005a Add a `test` script and coverage-reporting script in `package.json`
  - [x] T005b Configure Jest environment, transforms, and coverage thresholds in the required Jest config files
  - [x] T005c Define the coverage include scope for section components, `src/lib/usePortfolioData.ts`, navbar interactions, and `src/pages/index.tsx`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Create the shared data, styling, and deployment foundation that all stories depend on

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T006 Create strict portfolio data interfaces for all JSON sources in `src/types/portfolio.ts`
- [x] T007 [P] Implement shared JSON loader helpers or TanStack Query hooks in `src/lib/usePortfolioData.ts`
- [x] T007a [P] Document and implement the canonical skill-category remapping rules in `src/lib/usePortfolioData.ts` for frontend, backend, AI or agents, cloud, and a supporting fallback domain
- [x] T008 [P] Refactor the application shell in `src/pages/_app.tsx` to provide TanStack Query context and any app-level portfolio providers
- [x] T009 [P] Establish the global visual system, Tailwind tokens, and motion-safe base styles in `src/styles/globals.css`
- [x] T010 Create the top-level navigation shell and section anchor contract in `src/components/Navbar.tsx`
- [x] T011 [P] Add Jest unit tests for the shared portfolio data layer and navigation shell in `tests/` or colocated `*.test.tsx` files
  - [x] T011a [P] Add Jest tests for skill-domain normalization behavior in the data layer
  - [x] T011b [P] Add Jest tests for navbar anchor and social interaction behavior
- [x] T012 Create the GitHub Pages deployment workflow in `.github/workflows/deploy.yml`
- [x] T013 Document the production validation path for lint, Jest unit tests, coverage enforcement, and static export in `specs/001-portfolio-experience/quickstart.md`
  - [x] T013a Document the exact Jest coverage scope in `specs/001-portfolio-experience/quickstart.md`

**Checkpoint**: Foundation ready - user story implementation can now begin in priority order or in parallel if staffed

---

## Phase 3: User Story 1 - Establish the Portfolio Narrative (Priority: P1) 🎯 MVP

**Goal**: Deliver the hero, skills, and experience sections as a coherent first-impression narrative using typed JSON data and section-specific motion

**Independent Test**: Run the app with `personal.json`, `skills.json`, and `experience.json` populated, then verify hero CTA navigation, domain-grouped skills, and the previous-to-current experience timeline render correctly and remain usable with reduced motion preferences.

### Implementation for User Story 1

- [x] T014 [P] [US1] Implement the animated hero section in `src/components/Hero.tsx` using `db/personal.json` data contracts from `src/types/portfolio.ts`
- [x] T015 [P] [US1] Implement the domain-organized skills section in `src/components/Skills.tsx` using grouped data from `src/lib/usePortfolioData.ts`
- [x] T016 [P] [US1] Implement the chronology-first experience timeline in `src/components/Experience.tsx` using `db/experience.json` data
- [x] T017 [US1] Assemble the P1 narrative sections with `Navbar` in `src/pages/index.tsx` using strict typed props and section anchors
- [x] T018 [US1] Add graceful empty-state and reduced-motion handling for hero, skills, and experience in `src/components/Hero.tsx`, `src/components/Skills.tsx`, and `src/components/Experience.tsx`
- [x] T019 [P] [US1] Add Jest unit tests for `Hero`, `Skills`, `Experience`, and the composed P1 homepage narrative in `tests/` or colocated `*.test.tsx` files
  - [x] T019a [P] [US1] Add a Jest test for `Hero` CTA and personal data rendering
  - [x] T019b [P] [US1] Add a Jest test for `Skills` domain grouping and fallback-domain presentation
  - [x] T019c [P] [US1] Add a Jest test for `Experience` chronology-first rendering
  - [x] T019d [P] [US1] Add a Jest test for the composed homepage narrative and section anchor flow in `src/pages/index.tsx`
- [ ] T020 [US1] Validate the MVP narrative flow with lint, Jest unit tests, coverage thresholds, and a static production build from `package.json` scripts

**Checkpoint**: User Story 1 should present a fully usable portfolio narrative on its own and is the recommended MVP

---

## Phase 4: User Story 2 - Explore Proof of Work and Credentials (Priority: P2)

**Goal**: Add interactive proof sections for projects and certifications driven entirely by JSON data

**Independent Test**: Populate `db/projects.json` and `db/certification.json`, load the homepage, and verify project cards and certification actions render from data, open only valid links, and stay visually consistent with the portfolio design system.

### Implementation for User Story 2

- [x] T021 [P] [US2] Finalize the placeholder projects data contract and seed content in `db/projects.json`
- [x] T022 [P] [US2] Implement the interactive projects section in `src/components/Projects.tsx` using typed project metadata from `src/lib/usePortfolioData.ts`
- [x] T023 [P] [US2] Implement the certifications section with conditional verification actions in `src/components/Certifications.tsx`
- [x] T024 [US2] Integrate `Projects` and `Certifications` into the page composition in `src/pages/index.tsx`
- [x] T025 [US2] Add safeguards for missing project links and missing certification verification URLs in `src/components/Projects.tsx` and `src/components/Certifications.tsx`
- [x] T026 [P] [US2] Add Jest unit tests for `Projects`, `Certifications`, and their JSON-driven link handling in `tests/` or colocated `*.test.tsx` files
  - [x] T026a [P] [US2] Add a Jest test for `Projects` card rendering and optional-link gating
  - [x] T026b [P] [US2] Add a Jest test for `Certifications` rendering and conditional verification actions
- [ ] T027 [US2] Re-run lint, Jest unit tests, coverage thresholds, and static export validation after proof-section integration using the repository build commands in `package.json`

**Checkpoint**: User Stories 1 and 2 should work together with projects and credentials independently verifiable from JSON data

---

## Phase 5: User Story 3 - Reach Out Through Interactive Contact Paths (Priority: P3)

**Goal**: Complete the portfolio with icon-led contact actions that convert profile interest into outreach

**Independent Test**: Load only the social data dependency, verify the contact section renders GitHub, LinkedIn, and email actions from `db/social.json`, and confirm the email action uses `mailto:` while empty links do not render broken controls.

### Implementation for User Story 3

- [x] T028 [P] [US3] Implement the interactive contact section in `src/components/Contact.tsx` using typed data from `db/social.json`
- [x] T029 [US3] Integrate the contact section and any repeated social actions into `src/pages/index.tsx` and `src/components/Navbar.tsx`
- [x] T030 [US3] Add icon accessibility labels, outbound-link safety, and `mailto:` handling in `src/components/Contact.tsx`
- [x] T031 [P] [US3] Add Jest unit tests for `Contact` and navbar-social interactions in `tests/` or colocated `*.test.tsx` files
  - [x] T031a [P] [US3] Add a Jest test for `Contact` icon rendering and `mailto:` behavior
  - [x] T031b [P] [US3] Add a Jest test for navbar-social repeated action behavior when links are present or absent
- [ ] T032 [US3] Validate the complete homepage flow with contact interactions via lint, Jest unit tests, coverage thresholds, and a static production build

**Checkpoint**: All user stories should now be independently functional and integrated into one complete portfolio homepage

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Finish quality, deployment readiness, and documentation alignment across the full experience

- [x] T033 [P] Fine-tune cross-section spacing, responsive behavior, and visual consistency in `src/styles/globals.css` and `src/pages/index.tsx`
- [x] T034 [P] Review image paths, anchor navigation, outbound links, and test coverage reports for GitHub Pages static-hosting safety in `next.config.ts`, `src/pages/index.tsx`, and `src/components/*.tsx`
- [x] T035 Update the repository runtime guidance in `README.md` with portfolio setup, data sources, Jest testing commands, coverage expectations, and deployment notes
  - [x] T035a Document that Jest is feature-required and that release validation fails below 85% coverage
- [x] T036 Run the quickstart validation documented in `specs/001-portfolio-experience/quickstart.md`
- [ ] T037 Run final lint, Jest unit tests with coverage, and production static export validation for GitHub Pages using the repository scripts in `package.json`

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - blocks all user stories
- **User Story 1 (Phase 3)**: Depends on Foundational completion and delivers the MVP
- **User Story 2 (Phase 4)**: Depends on Foundational completion and should follow User Story 1 for a chronological delivery path
- **User Story 3 (Phase 5)**: Depends on Foundational completion and is safest after the main homepage layout is assembled
- **Polish (Phase 6)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Depends on typed data interfaces, data hooks, app providers, global styling, and navbar scaffolding
- **User Story 2 (P2)**: Depends on the same shared foundation plus the page composition introduced in User Story 1
- **User Story 3 (P3)**: Depends on the same shared foundation and final section assembly in `src/pages/index.tsx`

### Within Each User Story

- Shared data contracts and hooks come before section components
- Individual section components come before full-page assembly
- Error handling and empty-state behavior come before story-level validation
- Story validation completes before moving to the next chronological story

### Parallel Opportunities

- `T003`, `T004`, and `T005` can run in parallel after the initial repository audit
- `T007`, `T008`, `T009`, `T011`, and `T012` can run in parallel once the directory structure exists
- `T014`, `T015`, and `T016` can run in parallel after the shared data layer is complete
- `T021`, `T022`, and `T023` can run in parallel within User Story 2
- `T033` and `T034` can run in parallel during polish

---

## Parallel Example: User Story 1

```bash
# Launch the three main narrative sections together once the data hooks exist:
Task: "Implement the animated hero section in src/components/Hero.tsx"
Task: "Implement the domain-organized skills section in src/components/Skills.tsx"
Task: "Implement the chronology-first experience timeline in src/components/Experience.tsx"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational
3. Complete Phase 3: User Story 1
4. Validate hero, skills, and experience with lint, Jest unit tests, coverage enforcement, and static build
5. Demo the portfolio narrative before expanding to proof and contact sections

### Incremental Delivery

1. Finish setup and foundation
2. Ship User Story 1 as the first portfolio milestone
3. Add projects and certifications in User Story 2
4. Add contact conversion paths in User Story 3
5. Finish deployment and polish checks in Phase 6

### Chronological Checklist Alignment

1. Scaffold and audit the existing Pages Router base
2. Configure static export for GitHub Pages
3. Define typed JSON contracts
4. Build loader functions or TanStack Query hooks
5. Build modular section components
6. Assemble the full homepage in `src/pages/index.tsx`
7. Write and validate the GitHub Actions deployment workflow

---

## Notes

- The user requested `next.configure.js`, but the repository already uses `next.config.ts`; the tasks preserve the existing typed config file while implementing the required static export settings
- The user requested `types/portfolio.ts` or separate interface files; this task list assumes the shared-file approach from the approved plan
- Each task is intentionally concrete enough to execute without re-deriving architecture decisions from the spec
- Coverage enforcement must fail the validation flow if overall code coverage drops below 85%
