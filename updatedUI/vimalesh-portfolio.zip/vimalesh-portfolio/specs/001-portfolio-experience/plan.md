# Implementation Plan: Portfolio Experience

**Branch**: `001-portfolio-experience` | **Date**: 2026-08-09 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-portfolio-experience/spec.md`

## Summary

Build a visually distinctive single-page portfolio on the existing Next.js Pages Router
app by replacing the starter homepage with modular section components that consume typed
JSON data from `db/`. The implementation will enforce static export in the Next.js
configuration, introduce shared portfolio interfaces and TanStack Query-backed local data
hooks, and deliver a GitHub Pages deployment path with unoptimized images and a static
artifact workflow.

## Technical Context

**Language/Version**: TypeScript 5.x on Next.js 16.3.0 with React 19.2.8

**Primary Dependencies**: Next.js Pages Router, React, Tailwind CSS v4, TanStack Query,
Framer Motion, Jest, eslint-config-next

**Storage**: Local JSON files in `db/`

**Testing**: Jest-based unit tests for each portfolio section, shared data utilities,
navbar interaction behavior, and the composed homepage flow, plus ESLint, production
build validation, and a minimum 85% statement and branch coverage threshold

**Target Platform**: Static GitHub Pages deployment for modern desktop and mobile browsers

**Project Type**: Single-project web application

**Performance Goals**: Initial hero content visible within the first viewport on modern
mobile and desktop, smooth section transitions, and no runtime dependency on a Node.js
server

**Constraints**: Must preserve `output: 'export'`, use `images: { unoptimized: true }`,
consume only JSON-backed content under `db/`, keep strict TypeScript boundaries, use
Tailwind CSS for styling, use Framer Motion for animation, and keep TanStack Query usage
static-export compatible

**Quality Gates**: Every portfolio section component and shared portfolio data utility
must have Jest-based unit-test coverage, and the test suite must enforce at least 85%
overall code coverage before the feature is considered complete. Coverage scope includes
section components, `src/lib/usePortfolioData.ts`, navbar interactions, and the
composed homepage flow in `src/pages/index.tsx`.

**Scale/Scope**: One landing page with seven primary UI modules, six existing JSON data
sources plus one placeholder projects data source, and one GitHub Actions deployment
workflow

## Constitution Check

_GATE: Must pass before Phase 0 research. Re-check after Phase 1 design._

- Static export gate: Pass. The plan keeps the Pages Router, uses local JSON data,
  requires `next.config.ts` to add `output: 'export'`, and avoids API routes or server
  runtime features.
- JSON data gate: Pass. The plan uses `db/personal.json`, `db/skills.json`,
  `db/experience.json`, `db/projects.json`, `db/certification.json`, and
  `db/social.json` as the only content sources and introduces typed interfaces for each
  entity.
- Type safety gate: Pass. Shared interfaces will live in `src/types/portfolio.ts`
  because the current repository TypeScript configuration already targets `src/*` via the
  `@/*` path alias; the user-requested `types/portfolio.js` path is adjusted to a strict
  TypeScript file to satisfy the constitution.
- UI stack gate: Pass. Tailwind CSS remains the styling system and Framer Motion is the
  required animation layer for hero, timeline, project-card, and section reveal motion.
- Delivery gate: Pass. The plan includes production build validation and a
  `.github/workflows/deploy.yml` workflow for GitHub Pages artifact deployment.

## Project Structure

### Documentation (this feature)

```text
specs/001-portfolio-experience/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── portfolio-data-contract.md
└── tasks.md
```

### Source Code (repository root)

```text
db/
├── personal.json
├── skills.json
├── experience.json
├── projects.json
├── certification.json
└── social.json

src/
├── components/
│   ├── Contact.tsx
│   ├── Experience.tsx
│   ├── Hero.tsx
│   ├── Navbar.tsx
│   ├── Projects.tsx
│   ├── Certifications.tsx
│   └── Skills.tsx
├── lib/
│   └── usePortfolioData.ts
├── pages/
│   ├── _app.tsx
│   └── index.tsx
├── styles/
│   └── globals.css
└── types/
    └── portfolio.ts

tests/
├── components/
├── lib/
└── pages/

.github/
└── workflows/
    └── deploy.yml

next.config.ts
```

**Structure Decision**: Keep the existing single-project Pages Router layout and add
three focused directories under `src/`: `components/` for the section modules,
`lib/` for TanStack Query-backed JSON data access, and `types/` for the portfolio data
contracts, plus a root `tests/` tree for Jest coverage of components, shared data
utilities, and page composition. This preserves the current repo shape, aligns with the
`@/*` TypeScript path alias, and keeps the static-export hosting concerns centralized in
`next.config.ts` and the GitHub Actions workflow.

## Complexity Tracking

No constitutional violations currently require justification.
