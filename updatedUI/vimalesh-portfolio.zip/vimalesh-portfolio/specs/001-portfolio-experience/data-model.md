# Data Model: Portfolio Experience

## PersonalProfile

**Source**: `db/personal.json`

**Fields**:

- `name`: string, required
- `title`: string, required
- `tagline`: string, required
- `bio`: string, required
- `profilePhoto`: string, required
- `location`: string, required
- `email`: string, required

**Usage**: Powers the hero section identity block, CTA context, and fallback contact
email reference.

## SkillDomain

**Source**: `db/skills.json`

**Fields**:

- `category`: string, required
- `technologies`: string array, required

**Derived fields**:

- `displayDomain`: string, derived from category remapping for frontend, backend,
  AI or agents, cloud, and a supporting fallback domain when raw categories do not match
  the primary visitor-facing groups
- `accentStyle`: string token, derived for visual presentation

**Normalization rules**:

- Categories containing terms such as `frontend`, `ui`, `web`, or `client` map to
  `frontend`
- Categories containing terms such as `backend`, `api`, `server`, or `database` map to
  `backend`
- Categories containing terms such as `ai`, `ml`, `llm`, `agent`, or `genai` map to
  `ai-agents`
- Categories containing terms such as `cloud`, `devops`, `infra`, or `platform` map to
  `cloud`
- Any unmatched category maps to `supporting`

**Usage**: Drives clustered skill cards, marquees, or layered capability groupings.

## ExperienceEntry

**Source**: `db/experience.json`

**Fields**:

- `company`: string, required
- `position`: string, required
- `duration`: string, required
- `description`: string, required

**Derived fields**:

- `timelineOrder`: number, derived to preserve chronology from earlier roles to current
- `isCurrentRole`: boolean, derived from duration text or list position

**Usage**: Drives the experience timeline and its visual progression indicators.

## ProjectEntry

**Source**: `db/projects.json`

**Fields**:

- `slug`: string, required
- `name`: string, required
- `summary`: string, required
- `description`: string, required
- `status`: string, required
- `year`: string, required
- `tags`: string array, required
- `links.repository`: string, optional
- `links.demo`: string, optional
- `links.caseStudy`: string, optional
- `featured`: boolean, required

**Usage**: Drives interactive project cards, link actions, and featured-project emphasis.

## CertificationEntry

**Source**: `db/certification.json`

**Fields**:

- `name`: string, required
- `issuer`: string, required
- `date`: string, required
- `credentialId`: string, required
- `verificationUrl`: string, optional
- `description`: string, required

**Usage**: Drives credential tiles with conditional verification actions.

## SocialLinks

**Source**: `db/social.json`

**Fields**:

- `github`: string, optional
- `linkedin`: string, optional
- `email`: string, required

**Derived fields**:

- `mailtoHref`: string, derived from email

**Usage**: Drives the contact section and reusable navbar or footer actions.
