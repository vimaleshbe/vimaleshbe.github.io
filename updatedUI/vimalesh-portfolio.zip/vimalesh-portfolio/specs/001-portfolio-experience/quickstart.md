# Quickstart: Portfolio Experience

## Prerequisites

- Install project dependencies with `npm install`
- If npm cache permissions fail locally, use `npm_config_cache=$PWD/.npm-cache npm install`
- Ensure the JSON files under `db/` are present:
  - `personal.json`
  - `skills.json`
  - `experience.json`
  - `projects.json`
  - `certification.json`
  - `education.json`
  - `social.json`
  - `theme.json`

## Validation Steps

1. Confirm `next.config.ts` includes static export settings:
   - `output: 'export'`
   - `images: { unoptimized: true }`
2. Confirm the implementation includes these modules:
   - `src/types/portfolio.ts`
   - `src/lib/usePortfolioData.ts`
   - `src/components/Hero.tsx`
   - `src/components/Skills.tsx`
   - `src/components/Experience.tsx`
   - `src/components/Projects.tsx`
   - `src/components/Certifications.tsx`
   - `src/components/Contact.tsx`
   - `src/components/Navbar.tsx`
3. Run lint validation:

   ```bash
   npm run lint
   ```

   Expected result: command exits successfully with no ESLint errors.

4. Run the Jest unit test suite and confirm overall code coverage is at least 85%.

   ```bash
   npm test -- --runInBand
   ```

   Verified result in this repository:
   - 9 test suites passed
   - 20 tests passed
   - 100% statements
   - 96.77% branches
   - 100% functions
   - 100% lines

   Coverage scope must include:
   - Section components under `src/components/`
   - The shared data utility in `src/lib/usePortfolioData.ts`
   - Navbar interaction behavior
   - The composed homepage flow in `src/pages/index.tsx`

5. Run a production build and verify a static output directory is produced:

   ```bash
   npm run build
   ```

   Expected result: static export for GitHub Pages. If the command fails only inside a restricted sandbox with a Turbopack process or port-binding error, rerun it outside that sandbox before treating the build as invalid.

6. Start the local app when doing a manual validation pass:

   ```bash
   npm run dev
   ```

7. Open the generated static site or local development build and validate:
   - Hero renders data from `personal.json`
   - Skills render from `skills.json` with documented domain grouping and fallback mapping
   - Experience renders as a previous-to-current timeline from `experience.json`
   - Projects render from `projects.json`
   - Certifications open verification links when present
   - Contact icons open GitHub, LinkedIn, and `mailto:` actions
   - Motion remains usable when reduced motion is preferred
8. Review the GitHub Actions workflow definition at `.github/workflows/deploy.yml` for
   Pages deployment steps and expected branch or environment settings.

## Expected Outcome

The repository produces a static portfolio experience with all section content sourced
from JSON, modular typed components, verified Jest unit-test coverage of at least 85%,
and a deployment workflow suitable for GitHub Pages.

## Validation Record

The quickstart validation was executed against the current repository state with these confirmed results:

- `npm run lint` passed
- `npm test -- --runInBand` passed
- Coverage exceeded the 85% release threshold
- Production build remains environment-sensitive in restricted sandboxes and should be confirmed outside that restriction when needed
