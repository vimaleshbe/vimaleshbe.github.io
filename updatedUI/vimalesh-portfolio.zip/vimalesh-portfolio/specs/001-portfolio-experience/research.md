# Research: Portfolio Experience

## Decision 1: Retain the Pages Router and replace only the starter homepage

**Decision**: Implement the portfolio within the existing `src/pages` structure rather
than migrating to the App Router.

**Rationale**: The repository already uses the Pages Router and has no feature-specific
infrastructure yet. Reusing that structure keeps the change small, preserves deployment
predictability for static export, and avoids introducing migration work that does not add
portfolio value.

**Alternatives considered**:

- Migrate to the App Router: Rejected because it expands scope without being required for
  the requested single-page portfolio experience.
- Split the portfolio into multiple routes immediately: Rejected because the spec only
  requires section-based navigation and external certification links.

## Decision 2: Use typed local JSON access with TanStack Query wrappers

**Decision**: Create shared portfolio interfaces in `src/types/portfolio.ts` and a
`src/lib/usePortfolioData.ts` hook layer that exposes section-specific TanStack Query
helpers for JSON-backed content.

**Rationale**: The user explicitly asked for TanStack Query, and the constitution
requires typed JSON data contracts. Query wrappers provide consistent client-side data
access, future extensibility, and isolated mapping logic while staying compatible with a
static export because the data originates from local JSON files.

**Alternatives considered**:

- Import JSON directly in `index.tsx` only: Rejected because it centralizes too much data
  shaping in one file and weakens reuse and testability.
- Create one monolithic portfolio data context: Rejected because per-section hooks are
  simpler to reason about and map better to modular components.

## Decision 3: Correct the requested type file path to a TypeScript source file

**Decision**: Implement the data contracts in `src/types/portfolio.ts` instead of the
requested `types/portfolio.js`.

**Rationale**: The constitution requires strict TypeScript interfaces for all module
boundaries. A JavaScript file cannot satisfy that rule cleanly. Locating the file under
`src/types/` also matches the current path alias configuration.

**Alternatives considered**:

- Use `types/portfolio.js` with JSDoc typedefs: Rejected because it is a weaker typing
  solution and conflicts with the repository's strict TypeScript stance.
- Create multiple per-section type files: Rejected for now because one shared portfolio
  contract file is easier to discover and maintain at this scale.

## Decision 4: Use section-specific motion language rather than uniform animations

**Decision**: Use Framer Motion for distinct motion patterns per section: cinematic hero
reveal, staggered skill groups, vertical experience timeline progression, layered project
cards, credential lift interactions, and contact icon emphasis.

**Rationale**: The user asked for a more creative, eye-catching experience. A single
animation pattern across all sections would look generic. Section-specific motion keeps
the interface intentional while still using one animation system.

**Alternatives considered**:

- Keep all sections static: Rejected because it misses the requested visual ambition.
- Use CSS-only animations everywhere: Rejected because the constitution requires Framer
  Motion for animation work.

## Decision 5: Enforce static export and unoptimized image handling in Next.js config

**Decision**: Update `next.config.ts` to include `output: 'export'` and
`images: { unoptimized: true }`.

**Rationale**: GitHub Pages needs a serverless static output and does not support the
default Next.js image optimization server. This configuration satisfies the deployment
constraint directly.

**Alternatives considered**:

- Keep the default image optimization behavior: Rejected because it would break static
  hosting assumptions.
- Replace `next.config.ts` with `next.config.js`: Rejected because the repo already uses
  TypeScript config and there is no benefit to downgrading that file.

## Decision 6: Use GitHub Actions artifact deployment for Pages publishing

**Decision**: Define `.github/workflows/deploy.yml` to build the exported site and deploy
it through GitHub Pages.

**Rationale**: The user explicitly asked for automated deployment. A committed workflow
keeps publishing repeatable and visible in the repository.

**Alternatives considered**:

- Manual export and push to a Pages branch: Rejected because it is error-prone and not
  automated.
- Third-party CI deployment: Rejected because GitHub Actions is the simplest path for a
  GitHub-hosted static portfolio.

## Decision 7: Standardize component and data-layer tests on Jest

**Decision**: Use Jest as the required unit test framework for portfolio components,
page composition, and the shared `src/lib/usePortfolioData.ts` layer.

**Rationale**: The user explicitly requested Jest, and a single test runner keeps
coverage reporting, test execution, and component verification consistent across the
feature while supporting the 85% coverage gate.

**Alternatives considered**:

- Use Vitest or another test runner: Rejected because it would conflict with the
  requested Jest standard for this feature.
- Rely only on lint and manual checks: Rejected because it would not satisfy the
  required automated coverage threshold.
