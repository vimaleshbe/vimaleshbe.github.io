# Portfolio Data Contract

## Purpose

Define the expected JSON shapes and UI consumption rules for the static portfolio data
layer.

## Contract Rules

1. All homepage content MUST be sourced from JSON files under `db/`.
2. Every JSON file MUST map to an explicit TypeScript interface in
   `src/types/portfolio.ts`.
3. The data hook layer in `src/lib/usePortfolioData.ts` MUST be the single module that
   normalizes JSON imports before the data reaches section components.
4. Section components MUST receive typed props rather than importing raw JSON directly.
5. Optional outbound links MUST be checked before rendering interactive actions.
6. Missing optional values MUST degrade gracefully with omitted UI affordances rather than
   placeholder broken controls.
7. The normalized outputs from `src/lib/usePortfolioData.ts` MUST be covered by Jest
   unit tests so the data contract remains verifiable under the feature's 85% coverage
   gate.
8. Skill-category normalization in `src/lib/usePortfolioData.ts` MUST map raw categories
   into the visitor-facing domains `frontend`, `backend`, `ai-agents`, `cloud`, or
   `supporting` using documented keyword matching, and unmatched categories MUST fall
   back to `supporting`.

## JSON Sources

### `db/personal.json`

```json
{
  "personal": {
    "name": "string",
    "title": "string",
    "tagline": "string",
    "bio": "string",
    "profilePhoto": "string",
    "location": "string",
    "email": "string"
  }
}
```

### `db/skills.json`

```json
{
  "skills": [
    {
      "category": "string",
      "technologies": ["string"]
    }
  ]
}
```

### `db/experience.json`

```json
{
  "experience": [
    {
      "company": "string",
      "position": "string",
      "duration": "string",
      "description": "string"
    }
  ]
}
```

### `db/projects.json`

```json
{
  "projects": [
    {
      "slug": "string",
      "name": "string",
      "summary": "string",
      "description": "string",
      "status": "string",
      "year": "string",
      "tags": ["string"],
      "links": {
        "repository": "string",
        "demo": "string",
        "caseStudy": "string"
      },
      "featured": true
    }
  ]
}
```

### `db/certification.json`

```json
{
  "certifications": [
    {
      "name": "string",
      "issuer": "string",
      "date": "string",
      "credentialId": "string",
      "verificationUrl": "string",
      "description": "string"
    }
  ]
}
```

### `db/social.json`

```json
{
  "social": {
    "github": "string",
    "linkedin": "string",
    "email": "string"
  }
}
```
