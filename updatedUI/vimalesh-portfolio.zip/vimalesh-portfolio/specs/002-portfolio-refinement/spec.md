# Feature Specification: Portfolio Refinement

**Feature Branch**: `002-portfolio-refinement`

**Created**: 2026-08-09

**Status**: Implemented and refined

**Input**: User description: "To refine the portfolio write a new spec, Important don't update the exsisting `001-portfolio-experience` spec. instead create a new spec for this refinement as `002-portfoio-refinement` something like this 1. Navbar is fixed but on scroll behind scrolling sections are transparant it should not be. 2. Remove the text `Portfolio 2026` from the hero section. CURRENT FOCUS looks good need not to be touched. 3. Reduce the name (Vimalesh Jeyavelmani) text size and add profile image `public/profile.jpg` right side parallel to the name. Remove Explore Projects and Start a Conversation buttons. And this entire hero section should be in one view without scroll. Adjust the view accordingly. 4. CAPABILITIES section looks goog, need not to update anything. 5. Experience section doesn't looks good. It should be a timeline view as like in Linkedin experience section timeline view. Enchance/update the section as same like linkedin experience section. 6. Certification animations are all good, one change is even the card size is right for all cards who have description is big or small but the text `Credential ID and Verify Credential/Verification avaialable on request` is not consistent. It should be at the bottom or footer of all the cards regardless of description size. So it will look consistent. 7. Update the contact section in a different design instead of card, as most of the sections components are in cards view. And don't expose emailid, linkdinid and github id, that should be embedded only. 8. Lack of visual for seperating the sections, use the theme.json for some colors if usefull and make sense. 9. Add dark or light theme icon on top right corner of the navbar and create a them layout in a way for dark or light theme. Present theme and color coding we can keep it for dark and if light theme get selected use other colors should be visible good and add the colors you are using in `theme.json` and use it from there for thi portfolio so in feaute if the color needs to be updated can be done in one place. 10. Add or update the test coverage by writting or updating test cases using jest to acheive minimum 85% of code coverage."

## User Scenarios & Testing _(mandatory)_

### User Story 1 - Improve the First View and Navigation Shell (Priority: P1)

As a recruiter or hiring manager, I want the first screen to feel polished and stable so
I can understand Vimalesh's identity immediately without distracting transparent chrome,
oversized typography, or unnecessary hero controls.

**Why this priority**: The navbar and hero define the first impression. If those two
areas feel visually inconsistent or require scroll before the visitor understands the
opening narrative, the portfolio loses its highest-value moment.

**Independent Test**: Can be fully tested by loading the homepage with `personal.json`,
`social.json`, and `theme.json`, then confirming the navbar remains opaque while
scrolling, the hero fits in one desktop viewport, the profile image sits beside the hero
content, removed hero elements are absent, and the navbar theme toggle updates the page
palette.

**Acceptance Scenarios**:

1. **Given** a visitor scrolls through the homepage, **When** the fixed navbar remains
   pinned to the top, **Then** it keeps a solid or visually opaque background that
   prevents section content from showing through behind it.
2. **Given** valid hero data and the profile image asset in `public/profile.jpg`,
   **When** the homepage loads on desktop, **Then** the hero shows a reduced-size name,
   preserves the current-focus content, places the profile image parallel to the hero
   identity content, and fits within the opening viewport without requiring scroll.
3. **Given** the refined hero is rendered, **When** a visitor inspects it, **Then** the
   `Portfolio 2026`, `Explore Projects`, and `Start a Conversation` elements are not
   present.
4. **Given** the navbar includes a theme toggle icon, **When** a visitor switches theme,
   **Then** the site updates between dark and light visual modes using tokens sourced
   from `theme.json`.

---

### User Story 2 - Refine Section Rhythm and Supporting Proof (Priority: P2)

As a technical reviewer, I want the experience, certifications, and transitions between
sections to feel more intentional so the portfolio reads as a cohesive product instead of
stacked cards.

**Why this priority**: After the first screen is corrected, the next quality signal is
how the page sustains visual clarity and polish through the rest of the portfolio.

**Independent Test**: Can be tested independently by loading `experience.json`,
`certification.json`, and `theme.json`, then verifying the experience section groups
roles by company in chronological order with a visible timeline rail and no placeholder
marker copy, certification card footers align consistently across variable content, and
section separators improve the page rhythm without degrading readability.

**Acceptance Scenarios**:

1. **Given** valid experience data in `db/experience.json`, **When** a visitor reaches
   the experience section, **Then** the section groups consecutive roles by company,
   preserves chronological ordering with a visible timeline rail, and removes placeholder
   helper labels such as `Timeline marker` from the visible UI.
2. **Given** certification cards with different description lengths, **When** they are
   rendered, **Then** the `Credential ID` and verification action or fallback copy remain
   aligned at the bottom footer region of every card.
3. **Given** the page contains multiple major sections, **When** a visitor scrolls down
   the portfolio, **Then** visual separators using theme-aligned colors help distinguish
   the sections without overwhelming the content.
4. **Given** the capabilities section already meets expectations, **When** the
   refinement is implemented, **Then** that section remains substantively unchanged apart
   from global theme or spacing alignment.
5. **Given** the portfolio is switched to light theme, **When** the capabilities,
   projects, certifications, experience, and contact sections are visible, **Then** the
   headings, descriptions, cards, chips, actions, and separators remain clearly legible
   and visually cohesive with the active light palette.
6. **Given** certification cards contain footer content that wraps to different line
   counts, **When** the cards are rendered beside each other, **Then** the footer divider
   and the starting line for the `Credential ID` block remain aligned consistently across
   cards.

---

### User Story 3 - Redesign Contact Without Exposed Identifiers (Priority: P3)

As a potential collaborator, I want contact actions to feel deliberate and modern so I
can reach out quickly without seeing raw email addresses or profile identifiers printed
into the page.

**Why this priority**: Contact conversion matters after the narrative and supporting
proof are already strong, but it still needs to match the quality of the refined visual
system.

**Independent Test**: Can be tested independently by loading `social.json` and
confirming the contact section uses a non-card presentation, renders embedded GitHub,
LinkedIn, and email actions, and avoids displaying raw contact identifiers in visible
copy.

**Acceptance Scenarios**:

1. **Given** valid social data in `db/social.json`, **When** the contact section is
   rendered, **Then** it uses a design distinct from the portfolio's dominant card style
   while remaining visually cohesive.
2. **Given** GitHub, LinkedIn, and email actions are available, **When** a visitor views
   the contact section, **Then** those actions appear as embedded interactive controls
   rather than visible raw identifiers.
3. **Given** a visitor activates the email action, **When** the interaction is handled,
   **Then** the browser opens the configured `mailto:` link without showing the raw email
   address elsewhere in the page copy.
4. **Given** the navbar action cluster is visible, **When** a visitor inspects the theme,
   GitHub, LinkedIn, and email controls, **Then** each uses a dedicated icon asset rather
   than fallback text-only UI.

### Edge Cases

- What happens when the visitor toggles between dark and light theme mid-scroll while the
  navbar, separators, and refined sections are already visible?
- How does the hero layout adapt on small laptops or mobile screens when the profile
  image and identity copy must still stay readable and compact?
- How does the LinkedIn-style experience timeline handle many roles or unusually long
  descriptions without collapsing readability?
- What happens when certification entries do not include a verification URL and also have
  very different description lengths?
- What happens when certification footer text wraps to two or three lines in one card but
  not another within the same row?
- How does the system behave if `theme.json` is missing one or more light-theme tokens or
  contains incomplete optional values?
- How does the site preserve usability when reduced motion is preferred while refined
  timeline, separator, and theme-transition motion is present?

## Requirements _(mandatory)_

### Functional Requirements

- **FR-001**: The system MUST continue to deliver a single static-export-compatible
  portfolio experience in Next.js with JSON files under `db/` as the source of truth for
  section content and theme tokens.
- **FR-002**: The fixed navbar MUST remain visually opaque while scrolling so content from
  underlying sections does not show through in a distracting way.
- **FR-003**: The hero section MUST remove the `Portfolio 2026` label while preserving
  the current-focus content.
- **FR-004**: The hero section MUST reduce the visual size of the `Vimalesh
Jeyavelmani` heading compared with the current implementation while keeping it clearly
  prominent.
- **FR-005**: The hero section MUST place the image asset at `public/profile.jpg`
  alongside the hero identity content on larger viewports and adapt responsively on
  smaller screens.
- **FR-006**: The hero section MUST remove the `Explore Projects` and `Start a
Conversation` controls from the visible UI.
- **FR-007**: The hero section MUST fit its primary narrative within one standard desktop
  viewport without requiring initial scroll.
- **FR-008**: The capabilities section MUST remain substantively unchanged by this
  refinement except for minimal global theme, separator, or spacing adjustments.
- **FR-009**: The experience section MUST be redesigned into a grouped company-based
  timeline presentation with visible chronological structure that improves readability
  and chronology.
- **FR-010**: The certifications section MUST keep credential identifiers and
  verification actions or fallback copy anchored to a consistent bottom footer region for
  every card regardless of content length.
- **FR-010a**: Certification footer separators and the starting line of the `Credential
ID` block MUST remain visually aligned across cards even when credential metadata or
  verification text wraps to different line counts.
- **FR-011**: The contact section MUST use a visual pattern distinct from the portfolio's
  dominant card layout while still fitting the overall design language.
- **FR-012**: The contact section MUST provide embedded GitHub, LinkedIn, and email
  actions without exposing raw email addresses, GitHub identifiers, or LinkedIn
  identifiers as visible text.
- **FR-013**: The system MUST add visible separation between major homepage sections
  using values derived from or aligned with `db/theme.json`.
- **FR-014**: The navbar MUST include a dark and light theme toggle icon placed in the
  top-right area of the navigation layout.
- **FR-014a**: The navbar theme toggle MUST use the local `public/theme.jpg` asset, and
  the GitHub, LinkedIn, and email actions MUST use their dedicated local icon assets from
  `public/`.
- **FR-015**: The portfolio MUST support both dark and light visual themes, where the
  current palette can remain the dark direction and the light theme uses alternative
  colors that maintain strong readability.
- **FR-016**: Theme colors used for the portfolio refinement MUST be defined in
  `db/theme.json` so palette adjustments can be made centrally.
- **FR-016a**: The light-theme palette MUST preserve visible text, cards, chips, buttons,
  separators, and timeline chrome for the capabilities, projects, certifications,
  experience, and contact sections without requiring component-specific hardcoded dark
  colors.
- **FR-017**: The system MUST preserve reduced-motion usability for refined animations,
  including timeline presentation, theme transitions, and section reveal behaviors.
- **FR-018**: The system MUST continue to use Jest-based tests for affected homepage
  sections, navbar behavior, theme switching behavior, shared data logic, and the
  composed homepage flow, and enforced overall code coverage MUST remain at or above 85%
  before release.
- **FR-019**: Changes affecting presentation MUST specify how they remain compatible with
  Tailwind CSS, and if animation is involved, how Framer Motion is used.
- **FR-020**: Changes affecting content, theming, or assets MUST identify impacted `db/`
  JSON files, image assets, and the typed data contracts required to consume them safely.
- **FR-021**: Changes affecting routing, assets, rendering, or build behavior MUST state
  how static export compatibility for GitHub Pages is preserved.
- **FR-022**: The Current Focus metrics inside the hero card MUST remain horizontal cards
  placed side by side at the bottom of the card and must expand across the available card
  width instead of collapsing into a narrow left-aligned stack.
- **FR-023**: The refined experience presentation MUST remove any placeholder or helper
  marker copy such as `Timeline marker` labels from the visible UI.

### Key Entities _(include if feature involves data)_

- **PersonalProfile**: Represents hero identity content from `personal.json`, including
  name, title, tagline, current-focus content, and local profile-image usage.
- **ExperienceTimelineEntry**: Represents a role from `experience.json` displayed in a
  refined chronological timeline treatment.
- **CertificationEntry**: Represents a credential from `certification.json`, including
  description, credential identifier, and optional verification URL that must align into
  a consistent card footer.
- **SocialLinks**: Represents embedded outbound contact actions for GitHub, LinkedIn,
  and email sourced from `social.json`.
- **ThemeConfig**: Represents centralized color tokens from `theme.json` that drive dark
  and light presentation states, separators, and navbar styling.
- **ThemeActionAssets**: Represents the local icon assets used by the navbar for theme,
  GitHub, LinkedIn, and email actions.

## Success Criteria _(mandatory)_

### Measurable Outcomes

- **SC-001**: On a standard desktop viewport, the opening navbar and hero present
  Vimalesh's identity and profile image without requiring the visitor to scroll before
  understanding the first-screen narrative.
- **SC-002**: During manual validation, the fixed navbar remains visually legible and
  does not show distracting bleed-through from underlying sections at any scroll point.
- **SC-003**: During review against the previous implementation, the experience section
  presents a chronological timeline with distinct role markers, certification cards keep
  their credential footer content aligned to a shared bottom region regardless of
  description length, and the contact section renders as a non-card layout with only
  embedded outbound actions visible.
- **SC-003a**: During side-by-side review of certification cards with different footer
  wrapping, the footer divider and `Credential ID` baseline remain aligned across the row.
- **SC-004**: Theme switching between dark and light modes visibly updates the portfolio
  using values sourced from `theme.json` without causing inaccessible contrast or broken
  section separation.
- **SC-004a**: During manual light-theme review, the capabilities, projects,
  certifications, experience, and contact sections remain clearly visible without dark-only
  text or action styling bleeding through the active palette.
- **SC-005**: The published portfolio build can still be generated and deployed to its
  static hosting target without requiring a server runtime.
- **SC-006**: The Jest-based automated test suite covers the affected sections, theme
  behavior, navigation shell behavior, shared data handling, and homepage composition,
  and the enforced overall coverage threshold remains at or above 85% before release.

## Assumptions

- The refinement applies to the existing single-page portfolio and does not introduce a
  new route structure.
- The profile image will be available at `public/profile.jpg` and is safe for static
  export.
- The local icon assets in `public/theme.jpg`, `public/github.png`, `public/linkedin.png`,
  and `public/gmail.png` are available for navbar action rendering and are safe for static
  export.
- The current-focus content in the hero is intentionally retained and only repositioned
  as needed to fit the revised layout.
- The capabilities section should remain visually and functionally stable unless a minor
  global adjustment is necessary for theme or spacing consistency.
- `theme.json` can be expanded to support both dark and light tokens without breaking the
  JSON-driven architecture.
- Portfolio features are expected to ship on a statically exported Next.js site unless
  the constitution is amended.
