# Tasks: Portfolio Refinement

**Input**: Design documents from `/specs/002-portfolio-refinement/`

**Prerequisites**: plan.md (required), spec.md (required for user stories)

**Tests**: Jest-based unit tests are required for the refined navbar, hero, experience, certifications, contact section, theme behavior, shared data-loading layer, and the composed homepage flow. The implementation must enforce a minimum 85% overall code coverage threshold.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each refinement slice.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., [US1], [US2], [US3])
- Include exact file paths in descriptions

## Path Conventions

- **Single project**: `src/`, `tests/`, `db/`, and `public/` at repository root
- Paths below follow the current single-project Next.js repository layout

## Phase 1: Setup (Shared Refinement Preparation)

**Purpose**: Align the existing portfolio codebase with the refinement scope before user-story work begins

- [x] T001 Audit the current refinement surfaces in `src/components/`, `src/pages/index.tsx`, `src/styles/globals.css`, `src/lib/usePortfolioData.ts`, `src/types/portfolio.ts`, `db/theme.json`, and `public/profile.jpg` against `specs/002-portfolio-refinement/spec.md`, and record the requirement-to-file impact mapping for implementation kickoff
- [x] T002 [P] Extend the shared theme and portfolio data contracts in `src/types/portfolio.ts` for dark and light theme tokens and any refined component prop needs
- [x] T003 [P] Update shared data normalization in `src/lib/usePortfolioData.ts` to expose any new theme-token structure required by the refined navbar, section separators, and theme switching behavior
- [x] T004 [P] Prepare or verify the refinement asset and theme source data in `public/profile.jpg` and `db/theme.json` for centralized dark and light palette control
- [x] T005 [P] Explicitly document the impacted `db/` JSON files, `public/profile.jpg`, and typed contract touchpoints in `specs/002-portfolio-refinement/quickstart.md` and `specs/002-portfolio-refinement/tasks.md` so FR-020 remains reviewable during implementation
- [x] T006 [P] Expand Jest coverage planning and any shared test utilities for refined navbar, theme, hero, experience, certification, contact, and homepage behavior in `tests/` and the existing Jest config files if needed

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Create the shared styling and app-shell foundations the refinement stories depend on

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T007 Refactor app-level theme state handling in `src/pages/_app.tsx` and or `src/pages/index.tsx` so the portfolio can switch between dark and light themes without breaking static export behavior
- [x] T008 [P] Establish global theme variables, section-separator styling, and motion-safe theme-transition behavior in `src/styles/globals.css`
- [x] T009 [P] Refine the navigation shell contract in `src/components/Navbar.tsx` to support a fixed opaque background, top-right theme toggle icon, and any updated anchor or layout behavior
- [x] T010 [P] Add foundational Jest tests for shared theme behavior, navbar opacity behavior, and updated shared data handling in `tests/components/Navbar.test.tsx`, `tests/lib/usePortfolioData.test.ts`, and related test helpers
- [x] T011 [P] Verify and document Tailwind CSS compatibility and Framer Motion usage expectations for the refined navbar, hero, experience timeline, section separators, and contact interactions in `specs/002-portfolio-refinement/quickstart.md`, `src/components/`, and `src/styles/globals.css` to satisfy FR-019
- [x] T012 Document the refinement validation path for lint, Jest coverage, theme behavior checks, and static build validation in `specs/002-portfolio-refinement/quickstart.md`
- [x] T013 Add an explicit static-export compatibility checkpoint for theme toggling, local profile image usage, and homepage rendering changes in `specs/002-portfolio-refinement/quickstart.md`, `next.config.ts`, and `src/pages/index.tsx` to satisfy FR-021

**Checkpoint**: Shared theme, shell, and validation foundations are ready for feature refinements

---

## Phase 3: User Story 1 - Improve the First View and Navigation Shell (Priority: P1) 🎯 MVP

**Goal**: Deliver a stable first-screen experience with an opaque navbar, one-viewport hero, profile image, and dark or light theme switching

**Independent Test**: Run the homepage with `personal.json`, `social.json`, and `theme.json`, then verify the navbar stays opaque during scroll, the hero fits within the opening desktop viewport, removed hero elements are absent, and the theme toggle updates the page palette.

### Implementation for User Story 1

- [x] T014 [P] [US1] Refine the fixed navbar background, top-right theme toggle control, and responsive navigation layout in `src/components/Navbar.tsx`
- [x] T015 [P] [US1] Rework the hero layout in `src/components/Hero.tsx` to remove `Portfolio 2026`, preserve current-focus content, reduce the displayed name size, add `public/profile.jpg`, and remove the `Explore Projects` and `Start a Conversation` controls
- [x] T016 [US1] Update homepage composition and first-viewport spacing in `src/pages/index.tsx` and `src/styles/globals.css` so the navbar and hero fit cohesively without initial desktop scroll
- [x] T017 [US1] Add reduced-motion and responsive safeguards for the refined navbar and hero behavior in `src/components/Navbar.tsx`, `src/components/Hero.tsx`, and `src/styles/globals.css`
- [x] T018 [P] [US1] Add Jest unit tests for refined navbar opacity, theme-toggle behavior, hero rendering, removed hero actions, and first-screen composition in `tests/components/Navbar.test.tsx`, `tests/components/Hero.test.tsx`, and `tests/pages/index.test.tsx`
- [x] T019 [US1] Validate the refined first-screen experience with lint, Jest coverage, and static production build checks using the repository scripts in `package.json`

**Checkpoint**: User Story 1 should deliver a stable, polished, and theme-aware opening portfolio view on its own

---

## Phase 4: User Story 2 - Refine Section Rhythm and Supporting Proof (Priority: P2)

**Goal**: Improve the page’s supporting sections with a stronger timeline, consistent certification footers, and clearer section separation

**Independent Test**: Load `experience.json`, `certification.json`, and `theme.json`, then confirm the experience section reads as a LinkedIn-inspired timeline, certification footers align consistently across cards, and section separators visibly distinguish major sections.

### Implementation for User Story 2

- [x] T020 [P] [US2] Redesign the experience section in `src/components/Experience.tsx` into a more polished LinkedIn-inspired timeline using existing typed data from `db/experience.json`
- [x] T021 [P] [US2] Refine certification card structure in `src/components/Certifications.tsx` so credential metadata and verification actions or fallback copy remain anchored to the bottom footer region of each card
- [x] T022 [US2] Introduce theme-driven visual section separators and cross-section rhythm adjustments in `src/styles/globals.css` and `src/pages/index.tsx`
- [x] T023 [US2] Preserve capabilities-section stability while aligning surrounding spacing, separator behavior, and light-theme readability in `src/components/Skills.tsx`, `src/pages/index.tsx`, and `src/styles/globals.css`
- [x] T024 [P] [US2] Add Jest unit tests for timeline rendering, certification footer alignment behavior, and section-separator-aware homepage composition in `tests/components/Experience.test.tsx`, `tests/components/Certifications.test.tsx`, and `tests/pages/index.test.tsx`
- [x] T025 [US2] Re-run lint, Jest coverage, and static build validation after the section-rhythm refinements using the repository scripts in `package.json`
- [x] T025a [US2] Apply post-implementation light-theme fixes in `src/components/Skills.tsx`, `src/components/Projects.tsx`, `src/components/Certifications.tsx`, `src/components/Contact.tsx`, and `src/styles/globals.css` so section titles, descriptions, cards, chips, actions, and separators remain clearly visible in light mode
- [x] T025b [US2] Reserve a stable certification footer track in `src/components/Certifications.tsx` and `src/styles/globals.css` so the divider and `Credential ID` starting line remain aligned across cards with different footer wrapping
- [x] T025c [US2] Explicitly verify and document that the grouped company timeline, section separators, and supporting section chrome remain within Tailwind CSS and Framer Motion usage boundaries in `specs/002-portfolio-refinement/quickstart.md` and related component notes to keep FR-019 traceable through the section-rhythm work

**Checkpoint**: User Stories 1 and 2 should now provide a coherent, visually stronger portfolio flow from the hero through supporting proof sections

---

## Phase 5: User Story 3 - Redesign Contact Without Exposed Identifiers (Priority: P3)

**Goal**: Replace the card-based contact treatment with a more distinctive embedded-action section that keeps raw identifiers out of visible copy

**Independent Test**: Load `social.json`, then verify the contact section uses a non-card layout, still opens GitHub, LinkedIn, and email actions correctly, and does not display raw email, LinkedIn, or GitHub identifiers as visible text.

### Implementation for User Story 3

- [x] T026 [P] [US3] Redesign the contact section presentation in `src/components/Contact.tsx` to move away from the existing card treatment while preserving embedded interactive actions
- [x] T027 [US3] Update homepage integration and supporting spacing in `src/pages/index.tsx` and `src/styles/globals.css` so the new contact design fits the refined page rhythm
- [x] T028 [US3] Ensure visible copy and accessibility labels in `src/components/Contact.tsx` preserve outbound contact actions without exposing raw email addresses or profile identifiers in the main UI
- [x] T029 [P] [US3] Add Jest unit tests for the redesigned contact layout, embedded action behavior, and hidden-identifier expectations in `tests/components/Contact.test.tsx` and `tests/pages/index.test.tsx`
- [x] T030 [US3] Validate the complete homepage flow with the redesigned contact section via lint, Jest coverage, and static production build checks
- [x] T030a [US3] Align contact-section light-theme colors with the shared theme palette in `src/components/Contact.tsx`, `src/pages/index.tsx`, and `src/styles/globals.css`

**Checkpoint**: All refinement stories should now be independently functional and integrated into one complete portfolio experience

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Finish release-quality validation, documentation alignment, and final coverage verification for the refinement feature

- [x] T031 [P] Review `db/theme.json`, `public/profile.jpg`, and the refined page sections for GitHub Pages static-hosting safety and responsive behavior in `src/components/*.tsx`, `src/pages/index.tsx`, and `next.config.ts`
- [x] T032 [P] Update the repository runtime guidance for the refinement feature in `README.md` if the theme-switch, profile-image, icon-asset usage, light-theme validation, or build-validation guidance changes user-facing setup or validation steps
- [x] T033 Update `specs/002-portfolio-refinement/quickstart.md` with the final manual validation steps for navbar opacity, hero viewport fit, timeline layout, certification footer alignment, contact redesign, theme switching, Tailwind and Framer Motion compliance checks, impacted JSON and asset touchpoints, static-export checkpoints, and 85% coverage enforcement
- [x] T034 Run final lint, Jest unit tests with coverage, and production static export validation for `002-portfolio-refinement` using the repository scripts in `package.json`
- [x] T035 [US1] Replace navbar text-only action controls with local static icon assets in `src/components/Navbar.tsx` and verify them through `tests/components/Navbar.test.tsx`
- [x] T036 [US1] Preserve the full-width horizontal Current Focus metric layout in `src/components/Hero.tsx` and `src/styles/globals.css` so the bottom metrics span the hero card instead of collapsing into a narrow column
- [x] T037 [US2] Remove visible helper marker copy from the experience presentation and align the grouped company timeline treatment with the approved reference direction in `src/components/Experience.tsx`, `src/styles/globals.css`, and `tests/components/Experience.test.tsx`
- [x] T038 [P] Reconfirm and document the final GitHub Pages static-export safeguards for theme-toggle behavior, local icon and profile assets, and homepage rendering in `specs/002-portfolio-refinement/quickstart.md`, `README.md`, `next.config.ts`, and `src/pages/index.tsx` so FR-021 remains explicitly covered in the polish phase

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies and can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion and blocks all user-story implementation
- **User Story 1 (Phase 3)**: Depends on Foundational completion and delivers the MVP refinement
- **User Story 2 (Phase 4)**: Depends on Foundational completion and should follow User Story 1 for the cleanest visual-integration path
- **User Story 3 (Phase 5)**: Depends on Foundational completion and is safest after the refined page rhythm is established
- **Polish (Phase 6)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Depends on shared theme contracts, data exposure, global styling, and navbar shell readiness
- **User Story 2 (P2)**: Depends on the same shared foundation plus the refined first-screen composition from User Story 1
- **User Story 3 (P3)**: Depends on the shared foundation and final page rhythm introduced by User Stories 1 and 2

### Within Each User Story

- Shared data and theme support come before component-level refinement
- Component refinements come before full-page spacing and composition updates
- Reduced-motion, accessibility, and fallback handling come before story-level validation
- Story-level validation completes before moving to the next chronological refinement slice

### Parallel Opportunities

- `T002`, `T003`, `T004`, `T005`, and `T006` can run in parallel after the initial refinement audit
- `T008`, `T009`, `T010`, and `T011` can run in parallel once the shared refinement scope is confirmed
- `T014` and `T015` can run in parallel within User Story 1
- `T020` and `T021` can run in parallel within User Story 2
- `T031` and `T032` can run in parallel during polish

---

## Parallel Example: User Story 1

```bash
# Launch the core first-screen refinements together once shared theme foundations exist:
Task: "Refine the fixed navbar background and theme toggle in src/components/Navbar.tsx"
Task: "Rework the hero layout and profile image presentation in src/components/Hero.tsx"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational
3. Complete Phase 3: User Story 1
4. Validate navbar opacity, hero layout, theme switching, coverage, and static build behavior
5. Demo the refined first-screen portfolio before extending the supporting sections

### Incremental Delivery

1. Finish setup and shared theme foundations
2. Ship User Story 1 as the first-screen refinement milestone
3. Add the timeline, certification, and section-separator refinements in User Story 2
4. Add the redesigned contact conversion path in User Story 3
5. Finish documentation and release validation in Phase 6

### Chronological Checklist Alignment

1. Audit the current portfolio refinement surfaces
2. Extend shared theme and data contracts
3. Build shared theme-state and styling support
4. Refine navbar and hero behavior
5. Refine supporting sections and section rhythm
6. Redesign and validate the contact section
7. Finish coverage, build, and documentation validation

---

## Notes

- The refinement intentionally reuses the existing Pages Router and component architecture instead of creating parallel feature folders
- `db/theme.json` is treated as the single source of truth for new palette tokens used by dark and light mode plus section separators
- `public/profile.jpg`, `public/theme.jpg`, `public/github.png`, `public/linkedin.png`, and `public/gmail.png` are treated as local static assets and should remain compatible with GitHub Pages export expectations
- Coverage enforcement must continue to fail the validation flow if overall code coverage drops below 85%
