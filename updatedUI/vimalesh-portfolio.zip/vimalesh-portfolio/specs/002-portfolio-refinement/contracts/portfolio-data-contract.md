# Portfolio Data Contract

## Purpose

Define the expected JSON shapes, theme-token structure, and UI consumption rules for the
refined static portfolio data layer.

## Contract Rules

1. All homepage content and theme tokens MUST be sourced from JSON files under `db/`.
2. Every JSON file and theme token shape consumed by the homepage MUST map to an explicit
   TypeScript interface in `src/types/portfolio.ts`.
3. The data hook layer in `src/lib/usePortfolioData.ts` MUST remain the single module
   that normalizes JSON imports before the data reaches page or section components.
4. Section components MUST receive typed props rather than importing raw JSON directly.
5. `db/theme.json` MUST define both `dark` and `light` palette objects so navbar,
   separators, surfaces, text, and theme-switch behavior can be controlled centrally.
6. Theme normalization MUST provide safe defaults for missing optional palette values
   without breaking static rendering or theme switching.
7. The homepage theme toggle MUST consume normalized theme tokens rather than hardcoded
   inline color constants scattered across components.
8. Supporting sections such as capabilities, projects, certifications, experience, and
   contact MUST consume the active theme palette for readable text, card chrome, chips,
   actions, and separators instead of relying on hardcoded dark-only color values.
9. Navbar action controls MUST use local static icon assets from `public/` so the theme,
   GitHub, LinkedIn, and email affordances remain visually explicit in the exported site.
10. The local image asset path used by the hero MUST stay compatible with static export
    and be consumed through typed personal-profile data or fixed local asset usage that
    does not require runtime fetching.
11. Optional outbound links and verification URLs MUST be checked before rendering
    interactive actions.
12. Missing optional values MUST degrade gracefully with omitted UI affordances or
    fallback copy rather than broken controls.
13. The normalized outputs from `src/lib/usePortfolioData.ts`, including theme handling,
    MUST be covered by Jest unit tests so the data contract remains verifiable under the
    feature's 85% coverage gate.
14. Certification cards MUST reserve a stable footer region in the rendered UI so
    `Credential ID` metadata and verification actions or fallback copy align consistently
    across cards even when footer text wraps to different line counts.

## JSON Sources

### `db/personal.json`

```json
{
  "personal": {
    "name": "string",
    "title": "string",
    "tagline": "string",
    "bio": "string",
    "profilePhoto": "string",
    "location": "string",
    "email": "string"
  }
}
```

### `db/experience.json`

```json
{
  "experience": [
    {
      "company": "string",
      "position": "string",
      "duration": "string",
      "description": "string"
    }
  ]
}
```

### `db/certification.json`

```json
{
  "certifications": [
    {
      "name": "string",
      "issuer": "string",
      "date": "string",
      "credentialId": "string",
      "verificationUrl": "string",
      "description": "string"
    }
  ]
}
```

### `db/social.json`

```json
{
  "social": {
    "github": "string",
    "linkedin": "string",
    "email": "string"
  }
}
```

### `db/theme.json`

```json
{
  "theme": {
    "dark": {
      "primaryColor": "string",
      "secondaryColor": "string",
      "accentColor": "string",
      "backgroundColor": "string",
      "surfaceColor": "string",
      "surfaceMutedColor": "string",
      "textColor": "string",
      "textMutedColor": "string",
      "borderColor": "string",
      "separatorColor": "string",
      "navbarColor": "string"
    },
    "light": {
      "primaryColor": "string",
      "secondaryColor": "string",
      "accentColor": "string",
      "backgroundColor": "string",
      "surfaceColor": "string",
      "surfaceMutedColor": "string",
      "textColor": "string",
      "textMutedColor": "string",
      "borderColor": "string",
      "separatorColor": "string",
      "navbarColor": "string"
    }
  }
}
```

## Static Assets

- `public/profile.jpg`: Hero profile image.
- `public/theme.jpg`: Navbar theme-toggle icon.
- `public/github.png`: Navbar GitHub icon.
- `public/linkedin.png`: Navbar LinkedIn icon.
- `public/gmail.png`: Navbar email icon.
