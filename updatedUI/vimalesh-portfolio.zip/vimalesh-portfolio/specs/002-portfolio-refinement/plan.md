# Implementation Plan: Portfolio Refinement

**Branch**: `002-portfolio-refinement` | **Date**: 2026-08-09 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/002-portfolio-refinement/spec.md`

## Summary

Refine the existing static portfolio experience instead of rebuilding it: harden the
fixed navbar background, compress and rebalance the hero into a one-viewport opening
layout with a local profile image, redesign the experience section into a stronger
LinkedIn-inspired timeline, anchor certification metadata into consistent card footers,
replace the card-based contact section with a more distinctive embedded-action design,
introduce theme-driven section separators plus dark and light theme support from
`db/theme.json`, propagate theme-token styling through the capabilities, projects,
certifications, experience, and contact sections, align navbar actions to local icon
assets, preserve the full-width Current Focus metric row, and extend Jest coverage so the
affected components and shared data logic still enforce a minimum 85% release threshold.

## Technical Context

**Language/Version**: TypeScript 5.x on Next.js 16.3.0 with React 19.2.8

**Primary Dependencies**: Next.js Pages Router, React, Tailwind CSS v4, TanStack Query,
Framer Motion, Jest, eslint-config-next

**Storage**: Local JSON files in `db/` plus static assets in `public/`

**Testing**: Jest-based unit tests for affected section components, navbar and theme
interaction behavior, shared data utilities, composed homepage flow, ESLint, and static
production build validation with an enforced minimum 85% overall coverage threshold

**Target Platform**: Static GitHub Pages deployment for modern desktop and mobile browsers

**Project Type**: Single-project web application

**Performance Goals**: Navbar and hero remain stable during scroll, opening content fits
within the first desktop viewport, refined sections preserve smooth motion and readable
spacing on desktop and mobile, and theme switching does not cause layout instability

**Constraints**: Must preserve `output: 'export'`, use `images: { unoptimized: true }`,
consume JSON-backed content from `db/`, keep strict TypeScript boundaries, use Tailwind
CSS for styling, use Framer Motion for any animation changes, keep TanStack Query usage
static-export compatible, and keep production build execution compatible with the
repository's `next build --webpack` command

**Scale/Scope**: Refinement of one existing landing page, focused changes to shared theme
data, navbar, hero, experience, certifications, contact, page composition, global styles,
and the affected Jest suites

## Post-Implementation Refinement Notes

- Navbar action controls use local static assets from `public/`, including `theme.jpg`
  for the theme toggle and dedicated icons for GitHub, LinkedIn, and email.
- Light-theme readability must be validated on capabilities, projects, certifications,
  experience, and contact sections because those areas previously relied on hardcoded
  dark-only content colors.
- The Current Focus metrics in the hero card are intentionally kept as horizontal cards
  placed side by side at the bottom of the hero card and must span the available card
  width.
- The experience section follows a grouped company-based LinkedIn-style presentation and
  must not render helper copy such as `Timeline marker` labels.
- Certification cards require a reserved footer track so divider placement and
  `Credential ID` alignment remain stable even when footer content wraps to different
  line counts between adjacent cards.

## Constitution Check

_GATE: Must pass before Phase 0 research. Re-check after Phase 1 design._

- Static export gate: Pass. The refinement keeps the Pages Router, continues to use local
  JSON plus static assets, preserves `output: 'export'`, and does not introduce API
  routes, server rendering, or runtime hosting dependencies.
- JSON data gate: Pass. The plan touches `db/theme.json` for centralized dark and light
  palette tokens and continues consuming `db/personal.json`, `db/experience.json`,
  `db/certification.json`, and `db/social.json` through strict shared data contracts while
  also consuming static icon assets from `public/` for navbar actions.
- Type safety gate: Pass. Existing shared interfaces in `src/types/portfolio.ts` will be
  extended where needed for theme tokens and refined section props without using `any`.
- UI stack gate: Pass. Visual refinements stay within Tailwind CSS and existing global
  styles, while any refined transitions or timeline motion continue to use Framer Motion.
- Delivery gate: Pass. Completion still requires `npm run lint`, `npm test -- --runInBand`,
  coverage validation at 85% or higher, and `npm run build` using the repository's
  webpack-backed production build script.

## Project Structure

### Documentation (this feature)

```text
specs/002-portfolio-refinement/
├── plan.md
├── spec.md
├── quickstart.md
└── tasks.md
```

### Source Code (repository root)

```text
db/
├── certification.json
├── experience.json
├── personal.json
├── social.json
└── theme.json

public/
├── gmail.png
├── github.png
├── linkedin.png
└── profile.jpg

public/
└── theme.jpg

src/
├── components/
│   ├── Certifications.tsx
│   ├── Contact.tsx
│   ├── Experience.tsx
│   ├── Hero.tsx
│   ├── Navbar.tsx
│   └── Skills.tsx
├── lib/
│   └── usePortfolioData.ts
├── pages/
│   ├── _app.tsx
│   └── index.tsx
├── styles/
│   └── globals.css
└── types/
    └── portfolio.ts

tests/
├── components/
├── lib/
└── pages/
```

**Structure Decision**: Keep the existing single-project Pages Router structure and apply
the refinement within the current component, data, and test surfaces instead of creating
new feature folders. This keeps the changes local to the components that already own the
portfolio sections, centralizes palette updates in `db/theme.json` and shared types,
reuses `src/lib/usePortfolioData.ts` for theme-token and JSON normalization, and extends
the current Jest coverage model without introducing a parallel architecture.

## Complexity Tracking

No constitutional violations currently require justification.
