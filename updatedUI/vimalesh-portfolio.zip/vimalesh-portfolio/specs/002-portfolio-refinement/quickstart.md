# Quickstart: Portfolio Refinement

## Scope

This feature refines the existing static portfolio homepage without changing the routing model. The implementation keeps the Pages Router, continues sourcing content and theme tokens from `db/`, and preserves GitHub Pages static export compatibility.

## Impacted Data and Assets

- `db/theme.json`: Central source of truth for dark and light theme palettes, navbar colors, and section-separator colors.
- `db/personal.json`: Hero identity content and location metadata.
- `db/experience.json`: Timeline entries for the refined experience section.
- `db/certification.json`: Certification descriptions, credential IDs, and optional verification URLs.
- `db/social.json`: Embedded outbound actions for GitHub, LinkedIn, and email.
- `public/profile.jpg`: Local hero profile image used in the first-screen layout.
- `public/theme.jpg`: Local icon asset for the navbar theme toggle.
- `public/github.png`, `public/linkedin.png`, `public/gmail.png`: Local navbar action icons.
- `src/types/portfolio.ts`: Typed contracts for theme palettes and portfolio data.
- `src/lib/usePortfolioData.ts`: Normalization layer for JSON-backed content and theme tokens.

## UI Stack Compliance

- Styling remains Tailwind CSS first, with shared CSS utilities in `src/styles/globals.css` only for page-level tokens, separators, and reusable shell patterns.
- Animated behavior continues through Framer Motion in the navbar-adjacent hero reveal, experience timeline, and certification card entrances.
- Reduced-motion support is preserved through `useReducedMotion` in animated components and `prefers-reduced-motion` handling in global styles.

## Static Export Checkpoints

- `next.config.ts` must continue to enforce `output: "export"` and `images.unoptimized: true`.
- Theme switching must stay client-side only and must not introduce server-only APIs or runtime dependencies.
- `public/profile.jpg` must remain a local static asset referenced through Next image handling compatible with export mode.
- Homepage rendering changes in `src/pages/index.tsx` must continue to render from JSON-backed data without requiring API routes or server rendering.

## Manual Validation

1. Run `npm run dev` and open the homepage.
2. Verify the fixed navbar remains opaque while scrolling and that the top-right theme toggle switches between dark and light modes.
3. Confirm the hero removes `Portfolio 2026`, removes the old CTA buttons, shows the profile image, and fits within the opening desktop viewport without requiring initial scroll.
4. Confirm the experience section renders as a timeline with clear chronological markers and a visible current-role badge when applicable.
5. Confirm the experience section does not display placeholder helper copy such as `Timeline marker` labels and that grouped company roles remain readable.
6. Confirm the Current Focus metrics appear as two horizontal cards side by side at the bottom of the hero card and use the full card width.
7. Confirm certification cards keep the `Credential ID` and verification row aligned at the bottom regardless of description length, and that adjacent cards preserve the same divider and footer starting position even when footer text wraps differently.
8. Confirm the contact section uses embedded actions and does not expose raw email, LinkedIn, or GitHub identifiers in visible copy.
9. Confirm the navbar uses dedicated icon assets for theme, GitHub, LinkedIn, and email.
10. Confirm section separators are visible between major sections in both theme modes and remain readable.
11. Switch to light theme and verify Capabilities, Projects, Certifications, Experience, and Contact remain clearly visible with readable text, chips, actions, and card surfaces.

## Automated Validation

Run lint:

```bash
npm run lint
```

Run Jest with coverage:

```bash
npm test -- --runInBand
```

Coverage must remain at or above 85% overall.

Run the production build:

```bash
npm run build
```

## Focused Verification Slice

The following targeted command validates the refined theme, navbar, hero, experience, certifications, contact section, and homepage composition:

```bash
npm test -- --runInBand tests/lib/usePortfolioData.test.ts tests/components/Navbar.test.tsx tests/components/Hero.test.tsx tests/components/Experience.test.tsx tests/components/Certifications.test.tsx tests/components/Contact.test.tsx tests/pages/index.test.tsx
```

Verified result during implementation:

- Statements: 98.74%
- Branches: 86.86%
- Functions: 94.44%
- Lines: 98.74%
