import { useQuery } from "@tanstack/react-query";

import certificationData from "../../db/certification.json";
import educationData from "../../db/education.json";
import experienceData from "../../db/experience.json";
import personalData from "../../db/personal.json";
import projectsData from "../../db/projects.json";
import skillsData from "../../db/skills.json";
import socialData from "../../db/social.json";
import themeData from "../../db/theme.json";
import type {
  CertificationEntry,
  EducationEntry,
  ExperienceEntry,
  ExperienceTimelineEntry,
  PersonalProfile,
  PortfolioData,
  ProjectEntry,
  SkillDisplayDomain,
  SkillDomain,
  SkillEntry,
  SocialLinks,
  ThemeConfig,
} from "@/types/portfolio";

const DOMAIN_ACCENTS: Record<SkillDisplayDomain, string> = {
  frontend: "from-sky-400/30 via-cyan-300/10 to-transparent",
  backend: "from-emerald-400/30 via-teal-300/10 to-transparent",
  "ai-agents": "from-amber-300/35 via-orange-300/10 to-transparent",
  cloud: "from-indigo-400/30 via-violet-300/10 to-transparent",
  supporting: "from-stone-400/25 via-zinc-300/10 to-transparent",
};

const DOMAIN_KEYWORDS: Array<{
  domain: SkillDisplayDomain;
  keywords: string[];
}> = [
  { domain: "frontend", keywords: ["frontend", "ui", "web", "client"] },
  { domain: "backend", keywords: ["backend", "api", "server", "database"] },
  { domain: "ai-agents", keywords: ["ai", "ml", "llm", "agent", "genai"] },
  { domain: "cloud", keywords: ["cloud", "devops", "infra", "platform"] },
];

interface PersonalJson {
  personal: PersonalProfile;
}

interface SkillsJson {
  skills: SkillEntry[];
}

interface ExperienceJson {
  experience: ExperienceEntry[];
}

interface ProjectsJson {
  projects: ProjectEntry[];
}

interface CertificationsJson {
  certifications: CertificationEntry[];
}

interface SocialJson {
  social: SocialLinks;
}

interface ThemeJson {
  theme: ThemeConfig;
}

function normalizeThemePalette(theme: Partial<ThemeConfig>): ThemeConfig {
  const defaultDark = {
    primaryColor: "#38bdf8",
    secondaryColor: "#0f172a",
    accentColor: "#fbbf24",
    backgroundColor: "#020617",
    surfaceColor: "rgba(15, 23, 42, 0.78)",
    surfaceMutedColor: "rgba(15, 23, 42, 0.58)",
    textColor: "#e2e8f0",
    textMutedColor: "#94a3b8",
    borderColor: "rgba(148, 163, 184, 0.22)",
    separatorColor: "rgba(56, 189, 248, 0.26)",
    navbarColor: "rgba(2, 6, 23, 0.88)",
  };
  const defaultLight = {
    primaryColor: "#0f766e",
    secondaryColor: "#e2e8f0",
    accentColor: "#d97706",
    backgroundColor: "#f8fafc",
    surfaceColor: "rgba(255, 255, 255, 0.88)",
    surfaceMutedColor: "rgba(226, 232, 240, 0.72)",
    textColor: "#0f172a",
    textMutedColor: "#475569",
    borderColor: "rgba(15, 23, 42, 0.12)",
    separatorColor: "rgba(15, 118, 110, 0.18)",
    navbarColor: "rgba(248, 250, 252, 0.9)",
  };

  return {
    dark: { ...defaultDark, ...(theme.dark ?? {}) },
    light: { ...defaultLight, ...(theme.light ?? {}) },
  };
}

interface EducationJson {
  education: EducationEntry[];
}

export function normalizeSkillCategory(category: string): SkillDisplayDomain {
  const normalized = category.toLowerCase();

  const match = DOMAIN_KEYWORDS.find(({ keywords }) =>
    keywords.some((keyword) => normalized.includes(keyword)),
  );

  return match?.domain ?? "supporting";
}

export function normalizeSkillDomains(skills: SkillEntry[]): SkillDomain[] {
  return skills.map((skill) => {
    const displayDomain = normalizeSkillCategory(skill.category);

    return {
      ...skill,
      displayDomain,
      accentStyle: DOMAIN_ACCENTS[displayDomain],
    };
  });
}

export function normalizeExperience(
  entries: ExperienceEntry[],
): ExperienceTimelineEntry[] {
  return [...entries]
    .reverse()
    .map((entry, index, reversed) => ({
      ...entry,
      timelineOrder: index,
      isCurrentRole:
        index === reversed.length - 1 || /present/i.test(entry.duration),
    }))
    .reverse();
}

export function normalizeSocialLinks(social: SocialLinks) {
  return {
    ...social,
    github: social.github || undefined,
    linkedin: social.linkedin || undefined,
    mailtoHref: `mailto:${social.email}`,
  };
}

export function getPortfolioData(): PortfolioData {
  const personal = (personalData as PersonalJson).personal;
  const skillDomains = normalizeSkillDomains((skillsData as SkillsJson).skills);
  const experience = normalizeExperience(
    (experienceData as ExperienceJson).experience,
  );
  const projects = (projectsData as ProjectsJson).projects;
  const certifications = (
    certificationData as CertificationsJson
  ).certifications.map((item) => ({
    ...item,
    verificationUrl: item.verificationUrl || undefined,
  }));
  const social = normalizeSocialLinks((socialData as SocialJson).social);
  const theme = normalizeThemePalette((themeData as ThemeJson).theme);
  const education = (educationData as EducationJson).education;

  return {
    personal,
    skillDomains,
    experience,
    projects,
    certifications,
    social,
    theme,
    education,
  };
}

export function usePortfolioData() {
  return useQuery({
    queryKey: ["portfolio-data"],
    queryFn: async () => getPortfolioData(),
    initialData: getPortfolioData,
  });
}
