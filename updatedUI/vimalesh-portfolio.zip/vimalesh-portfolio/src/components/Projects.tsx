import { motion, useReducedMotion } from "framer-motion";

import type { ProjectEntry, ThemePalette } from "@/types/portfolio";

interface ProjectsProps {
  projects: ProjectEntry[];
  theme: ThemePalette;
}

export function Projects({ projects, theme }: ProjectsProps) {
  const reduceMotion = useReducedMotion();

  return (
    <section id="projects" className="section-shell">
      <div className="section-heading">
        <p>Projects</p>
        <h2>
          Interactive work shaped by AI orchestration, data systems, and
          platform thinking.
        </h2>
      </div>
      <div className="grid gap-5 xl:grid-cols-2">
        {projects.map((project, index) => {
          const actions = [
            project.links.demo
              ? { href: project.links.demo, label: "Live demo" }
              : null,
            project.links.repository
              ? { href: project.links.repository, label: "Repository" }
              : null,
            project.links.caseStudy
              ? { href: project.links.caseStudy, label: "Case study" }
              : null,
          ].filter(Boolean) as Array<{ href: string; label: string }>;

          return (
            <motion.article
              key={project.slug}
              initial={reduceMotion ? false : { opacity: 0, y: 22 }}
              whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.45, delay: index * 0.05 }}
              className="project-card"
              style={{ borderColor: theme.borderColor }}
            >
              <div className="flex items-start justify-between gap-6">
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    <span className="status-pill">{project.status}</span>
                    <span className="chip">{project.year}</span>
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="text-2xl font-semibold"
                      style={{ color: theme.textColor }}
                    >
                      {project.name}
                    </h3>
                    <p
                      className="text-lg"
                      style={{ color: theme.textMutedColor }}
                    >
                      {project.summary}
                    </p>
                  </div>
                </div>
                {project.featured ? (
                  <span className="featured-badge">Featured</span>
                ) : null}
              </div>
              <p className="leading-7" style={{ color: theme.textMutedColor }}>
                {project.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span key={tag} className="chip">
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex flex-wrap gap-3">
                {actions.length > 0 ? (
                  actions.map((action) => (
                    <a
                      key={action.label}
                      href={action.href}
                      target="_blank"
                      rel="noreferrer"
                      className="button-secondary"
                    >
                      {action.label}
                    </a>
                  ))
                ) : (
                  <span
                    className="text-sm"
                    style={{ color: theme.textMutedColor }}
                  >
                    Project links will be published with the production case
                    study.
                  </span>
                )}
              </div>
            </motion.article>
          );
        })}
      </div>
    </section>
  );
}
