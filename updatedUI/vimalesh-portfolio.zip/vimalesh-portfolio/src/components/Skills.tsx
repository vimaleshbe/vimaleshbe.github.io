import { motion, useReducedMotion } from "framer-motion";

import type { SkillDomain, ThemePalette } from "@/types/portfolio";

interface SkillsProps {
  skillDomains: SkillDomain[];
  theme: ThemePalette;
}

const DOMAIN_LABELS: Record<SkillDomain["displayDomain"], string> = {
  frontend: "Frontend Systems",
  backend: "Backend Platforms",
  "ai-agents": "AI + Agentic Orchestration",
  cloud: "Cloud and DevOps",
  supporting: "Supporting Stack",
};

export function Skills({ skillDomains, theme }: SkillsProps) {
  const reduceMotion = useReducedMotion();

  return (
    <section id="skills" className="section-shell">
      <div className="section-heading">
        <p>Capabilities</p>
        <h2>
          Specializations arranged for how teams actually evaluate modern
          technical depth.
        </h2>
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        {skillDomains.map((skill, index) => (
          <motion.article
            key={`${skill.category}-${index}`}
            initial={reduceMotion ? false : { opacity: 0, y: 22 }}
            whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: index * 0.05 }}
            className={`skill-card bg-gradient-to-br ${skill.accentStyle}`}
            style={{ borderColor: theme.borderColor }}
          >
            <div className="space-y-2">
              <p
                className="text-xs uppercase tracking-[0.32em]"
                style={{ color: theme.primaryColor }}
              >
                {DOMAIN_LABELS[skill.displayDomain]}
              </p>
              <h3
                className="text-2xl font-semibold"
                style={{ color: theme.textColor }}
              >
                {skill.category}
              </h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {skill.technologies.map((technology) => (
                <span key={technology} className="chip">
                  {technology}
                </span>
              ))}
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
