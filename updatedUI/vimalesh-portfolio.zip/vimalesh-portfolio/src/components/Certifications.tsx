import { motion, useReducedMotion } from "framer-motion";

import type { CertificationEntry, ThemePalette } from "@/types/portfolio";

interface CertificationsProps {
  certifications: CertificationEntry[];
  theme: ThemePalette;
}

export function Certifications({ certifications, theme }: CertificationsProps) {
  const reduceMotion = useReducedMotion();

  return (
    <section id="certifications" className="section-shell">
      <div className="section-heading">
        <p>Certifications</p>
        <h2>
          Credential trail across cloud, AI engineering, workflow orchestration,
          and data platforms.
        </h2>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {certifications.map((certification, index) => (
          <motion.article
            key={`${certification.name}-${certification.credentialId}`}
            initial={reduceMotion ? false : { opacity: 0, y: 18 }}
            whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, delay: index * 0.03 }}
            className="certification-card certification-card-balanced"
            style={{ borderColor: theme.borderColor }}
          >
            <div className="certification-card-body">
              <div className="space-y-2">
                <p
                  className="text-sm uppercase tracking-[0.3em]"
                  style={{ color: theme.textMutedColor }}
                >
                  {certification.date}
                </p>
                <h3
                  className="text-xl font-semibold"
                  style={{ color: theme.textColor }}
                >
                  {certification.name}
                </h3>
                <p
                  className="text-sm font-medium"
                  style={{ color: theme.primaryColor }}
                >
                  {certification.issuer}
                </p>
              </div>
              <p className="leading-7" style={{ color: theme.textMutedColor }}>
                {certification.description}
              </p>
            </div>
            <div
              className="certification-footer text-sm"
              style={{ color: theme.textMutedColor }}
            >
              <div className="certification-footer-meta">
                <span className="font-medium">Credential ID</span>
                <span>{certification.credentialId}</span>
              </div>
              {certification.verificationUrl ? (
                <a
                  href={certification.verificationUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="certification-link certification-footer-action"
                  style={{ color: theme.primaryColor }}
                >
                  Verify credential
                </a>
              ) : (
                <span className="certification-footer-action">
                  Verification available on request
                </span>
              )}
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
