import { motion, useReducedMotion } from "framer-motion";
import Image from "next/image";

import type { PersonalProfile, ThemePalette } from "@/types/portfolio";

interface HeroProps {
  personal: PersonalProfile;
  theme: ThemePalette;
}

export function Hero({ personal, theme }: HeroProps) {
  const reduceMotion = useReducedMotion();

  return (
    <section
      id="hero"
      className="portfolio-grid min-h-[calc(100vh-5rem)] items-center gap-8 pt-6 lg:grid-cols-[1.1fr_0.9fr] lg:pt-10"
    >
      <motion.div
        initial={reduceMotion ? false : { opacity: 0, y: 28 }}
        animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="space-y-6"
      >
        <div
          className="inline-flex items-center gap-3 rounded-full border px-4 py-2 text-xs font-medium uppercase tracking-[0.3em]"
          style={{
            borderColor: theme.borderColor,
            backgroundColor: theme.surfaceMutedColor,
            color: theme.primaryColor,
          }}
        >
          <span
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: theme.accentColor }}
          />
          {personal.location}
        </div>
        <div className="space-y-4">
          <h1
            className="max-w-4xl text-4xl font-semibold leading-[0.95] sm:text-5xl lg:text-6xl"
            style={{ color: theme.textColor }}
          >
            {personal.name}
          </h1>
          <p
            className="max-w-3xl text-lg sm:text-xl"
            style={{ color: theme.primaryColor }}
          >
            {personal.title}
          </p>
          <p
            className="max-w-2xl text-base leading-7 sm:text-lg"
            style={{ color: theme.textMutedColor }}
          >
            {personal.tagline}
          </p>
        </div>
        <p
          className="max-w-3xl text-base leading-7 sm:text-lg"
          style={{ color: theme.textMutedColor }}
        >
          {personal.bio}
        </p>
      </motion.div>

      <motion.aside
        initial={reduceMotion ? false : { opacity: 0, scale: 0.95 }}
        animate={reduceMotion ? undefined : { opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.08, ease: "easeOut" }}
        className="hero-card hero-card-split"
        style={{
          backgroundColor: theme.surfaceColor,
          borderColor: theme.borderColor,
        }}
      >
        <div className="hero-image-shell">
          <Image
            src="/profile.jpg"
            alt={`${personal.name} profile`}
            width={420}
            height={520}
            priority
            className="hero-image"
          />
        </div>
        <div className="space-y-5 hero-focus-content">
          <p
            className="text-xs uppercase tracking-[0.3em]"
            style={{ color: theme.primaryColor }}
          >
            Current focus
          </p>
          <div className="space-y-3" style={{ color: theme.textColor }}>
            <h2 className="text-2xl font-semibold">
              Agentic systems with enterprise discipline
            </h2>
            <p className="leading-7" style={{ color: theme.textMutedColor }}>
              Designing orchestration-first platforms that connect AI agents,
              data products, and resilient architecture patterns into practical
              delivery workflows.
            </p>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 hero-metrics-grid">
          <div
            className="metric-card metric-card-horizontal"
            style={{
              backgroundColor: theme.surfaceMutedColor,
              borderColor: theme.borderColor,
            }}
          >
            <span className="metric-value" style={{ color: theme.textColor }}>
              10+
            </span>
            <span
              className="metric-label"
              style={{ color: theme.textMutedColor }}
            >
              Years in architecture and data engineering
            </span>
          </div>
          <div
            className="metric-card metric-card-horizontal"
            style={{
              backgroundColor: theme.surfaceMutedColor,
              borderColor: theme.borderColor,
            }}
          >
            <span className="metric-value" style={{ color: theme.textColor }}>
              4
            </span>
            <span
              className="metric-label"
              style={{ color: theme.textMutedColor }}
            >
              Core domains across AI, cloud, backend, frontend
            </span>
          </div>
        </div>
      </motion.aside>
    </section>
  );
}
