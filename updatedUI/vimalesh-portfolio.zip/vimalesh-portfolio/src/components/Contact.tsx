import type { SocialLinks } from "@/types/portfolio";

interface ContactProps {
  social: SocialLinks & { mailtoHref: string };
  theme: {
    primaryColor: string;
    textColor: string;
    textMutedColor: string;
    borderColor: string;
    surfaceColor: string;
    surfaceMutedColor: string;
  };
}

export function Contact({ social, theme }: ContactProps) {
  const items = [
    social.github
      ? {
          href: social.github,
          label: "GitHub",
          summary: "Review open-source activity and current experiments.",
          cta: "Open GitHub profile",
        }
      : null,
    social.linkedin
      ? {
          href: social.linkedin,
          label: "LinkedIn",
          summary:
            "Connect for architecture, AI, and leadership conversations.",
          cta: "Open LinkedIn profile",
        }
      : null,
    {
      href: social.mailtoHref,
      label: "Email",
      summary:
        "Start a direct conversation about architecture, AI, and delivery.",
      cta: "Compose email",
    },
  ].filter(Boolean) as Array<{
    href: string;
    label: string;
    summary: string;
    cta: string;
  }>;

  return (
    <section id="contact" className="section-shell pb-20">
      <div className="section-heading">
        <p>Contact</p>
        <h2>Open to architecture, platform, and AI delivery conversations.</h2>
      </div>
      <div className="contact-panel">
        <div className="space-y-4">
          <p
            className="text-sm uppercase tracking-[0.32em]"
            style={{ color: theme.primaryColor }}
          >
            Embedded channels
          </p>
          <p
            className="max-w-2xl text-lg leading-8"
            style={{ color: theme.textMutedColor }}
          >
            Reach out through the channel that fits the conversation. The
            section keeps the focus on action rather than exposing raw
            identifiers in the visible UI.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {items.map((item) => (
            <a
              key={item.label}
              href={item.href}
              aria-label={item.label}
              target={item.href.startsWith("mailto:") ? undefined : "_blank"}
              rel={item.href.startsWith("mailto:") ? undefined : "noreferrer"}
              className="contact-action"
              style={{
                borderColor: theme.borderColor,
                background: `linear-gradient(180deg, ${theme.surfaceColor}, ${theme.surfaceMutedColor})`,
              }}
            >
              <span
                className="text-sm uppercase tracking-[0.3em]"
                style={{ color: theme.primaryColor }}
              >
                {item.label}
              </span>
              <span
                className="text-xl font-semibold"
                style={{ color: theme.textColor }}
              >
                {item.summary}
              </span>
              <span
                className="text-sm font-medium"
                style={{ color: theme.primaryColor }}
              >
                {item.cta}
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
