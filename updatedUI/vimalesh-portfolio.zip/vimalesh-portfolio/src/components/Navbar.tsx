import Image from "next/image";

import type { SocialLinks, ThemePalette } from "@/types/portfolio";

interface NavbarProps {
  social: SocialLinks & { mailtoHref: string };
  themeMode: "dark" | "light";
  onToggleTheme: () => void;
  theme: ThemePalette;
}

const NAV_ITEMS = [
  { href: "#hero", label: "Intro" },
  { href: "#skills", label: "Skills" },
  { href: "#experience", label: "Experience" },
  { href: "#projects", label: "Projects" },
  { href: "#certifications", label: "Certifications" },
  { href: "#contact", label: "Contact" },
];

export function Navbar({
  social,
  themeMode,
  onToggleTheme,
  theme,
}: NavbarProps) {
  const socialLinks = [
    social.github
      ? { href: social.github, label: "GitHub", iconSrc: "/github.png" }
      : null,
    social.linkedin
      ? { href: social.linkedin, label: "LinkedIn", iconSrc: "/linkedin.png" }
      : null,
    { href: social.mailtoHref, label: "Email", iconSrc: "/gmail.png" },
  ].filter(Boolean) as Array<{
    href: string;
    label: string;
    iconSrc: string;
  }>;

  return (
    <header
      className="sticky top-0 z-50 border-b backdrop-blur-xl transition-colors duration-300"
      style={{
        backgroundColor: theme.navbarColor,
        borderColor: theme.borderColor,
      }}
    >
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-6 px-6 py-4 lg:px-10">
        <a
          href="#hero"
          className="text-sm font-semibold uppercase tracking-[0.32em]"
          style={{ color: theme.textColor }}
        >
          Vimalesh
        </a>
        <nav className="hidden items-center gap-5 md:flex">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm transition"
              style={{ color: theme.textMutedColor }}
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={`Activate ${themeMode === "dark" ? "light" : "dark"} theme`}
            className="flex h-10 w-10 items-center justify-center rounded-full border text-sm font-semibold transition"
            style={{
              borderColor: theme.borderColor,
              backgroundColor: theme.surfaceMutedColor,
              color: theme.textColor,
            }}
          >
            <Image
              src="/theme.jpg"
              alt=""
              width={18}
              height={18}
              aria-hidden="true"
            />
          </button>
          {socialLinks.map((item) => (
            <a
              key={item.label}
              href={item.href}
              aria-label={item.label}
              target={item.href.startsWith("mailto:") ? undefined : "_blank"}
              rel={item.href.startsWith("mailto:") ? undefined : "noreferrer"}
              className="flex h-10 w-10 items-center justify-center rounded-full border text-xs font-semibold transition"
              style={{
                borderColor: theme.borderColor,
                backgroundColor: theme.surfaceMutedColor,
              }}
            >
              <Image
                src={item.iconSrc}
                alt=""
                width={18}
                height={18}
                aria-hidden="true"
              />
            </a>
          ))}
        </div>
      </div>
    </header>
  );
}
