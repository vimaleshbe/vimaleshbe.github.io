import { motion, useReducedMotion } from "framer-motion";

import type { ExperienceTimelineEntry } from "@/types/portfolio";

interface ExperienceProps {
  experience: ExperienceTimelineEntry[];
}

interface ExperienceGroup {
  company: string;
  roles: ExperienceTimelineEntry[];
}

function groupExperienceByCompany(
  experience: ExperienceTimelineEntry[],
): ExperienceGroup[] {
  return experience.reduce<ExperienceGroup[]>((groups, entry) => {
    const previousGroup = groups.at(-1);

    if (previousGroup?.company === entry.company) {
      previousGroup.roles.push(entry);
      return groups;
    }

    groups.push({ company: entry.company, roles: [entry] });
    return groups;
  }, []);
}

export function Experience({ experience }: ExperienceProps) {
  const reduceMotion = useReducedMotion();
  const groupedExperience = groupExperienceByCompany(experience);

  return (
    <section id="experience" className="section-shell">
      <div className="section-heading">
        <p>Experience</p>
        <h2>
          A progression from engineering craft to architecture leadership.
        </h2>
      </div>
      <div className="experience-groups">
        {groupedExperience.map((group, groupIndex) => (
          <motion.article
            key={`${group.company}-${groupIndex}`}
            initial={reduceMotion ? false : { opacity: 0, y: 20 }}
            whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: groupIndex * 0.06 }}
            className="experience-company-group"
          >
            <div className="experience-company-header">
              <div className="experience-company-mark" aria-hidden="true">
                {group.company.slice(0, 1)}
              </div>
              <div className="space-y-1">
                <p className="experience-company-name">{group.company}</p>
                <p className="experience-company-summary">
                  {group.roles[0]?.duration}
                  {group.roles.length > 1
                    ? ` · ${group.roles.length} roles`
                    : ""}
                </p>
              </div>
            </div>
            <div className="experience-role-list">
              {group.roles.map((entry) => (
                <div
                  key={`${entry.company}-${entry.position}-${entry.duration}`}
                  className="experience-role-item"
                >
                  <div className="experience-role-rail" aria-hidden="true">
                    <span className="experience-role-dot" />
                    <span className="experience-role-line" />
                  </div>
                  <div className="experience-role-content">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <h3 className="experience-role-title">
                        {entry.position}
                      </h3>
                      {entry.isCurrentRole ? (
                        <span className="status-pill">Current</span>
                      ) : null}
                    </div>
                    <p className="experience-role-duration">{entry.duration}</p>
                    <p className="experience-role-description">
                      {entry.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
