export type SkillDisplayDomain =
  | "frontend"
  | "backend"
  | "ai-agents"
  | "cloud"
  | "supporting";

export interface PersonalProfile {
  name: string;
  title: string;
  tagline: string;
  bio: string;
  profilePhoto: string;
  location: string;
  email: string;
}

export interface SkillEntry {
  category: string;
  technologies: string[];
}

export interface SkillDomain {
  category: string;
  technologies: string[];
  displayDomain: SkillDisplayDomain;
  accentStyle: string;
}

export interface ExperienceEntry {
  company: string;
  position: string;
  duration: string;
  description: string;
}

export interface ExperienceTimelineEntry extends ExperienceEntry {
  timelineOrder: number;
  isCurrentRole: boolean;
}

export interface ProjectLinks {
  repository?: string;
  demo?: string;
  caseStudy?: string;
}

export interface ProjectEntry {
  slug: string;
  name: string;
  summary: string;
  description: string;
  status: string;
  year: string;
  tags: string[];
  links: ProjectLinks;
  featured: boolean;
}

export interface CertificationEntry {
  name: string;
  issuer: string;
  date: string;
  credentialId: string;
  verificationUrl?: string;
  description: string;
}

export interface SocialLinks {
  github?: string;
  linkedin?: string;
  email: string;
}

export interface ThemePalette {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  surfaceColor: string;
  surfaceMutedColor: string;
  textColor: string;
  textMutedColor: string;
  borderColor: string;
  separatorColor: string;
  navbarColor: string;
}

export interface ThemeConfig {
  dark: ThemePalette;
  light: ThemePalette;
}

export interface EducationEntry {
  degree: string;
  institution: string;
  year: string;
  description: string;
}

export interface PortfolioData {
  personal: PersonalProfile;
  skillDomains: SkillDomain[];
  experience: ExperienceTimelineEntry[];
  projects: ProjectEntry[];
  certifications: CertificationEntry[];
  social: SocialLinks & { mailtoHref: string };
  theme: ThemeConfig;
  education: EducationEntry[];
}
