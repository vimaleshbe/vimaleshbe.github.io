import { useEffect, useState } from "react";

import { Certifications } from "@/components/Certifications";
import { Contact } from "@/components/Contact";
import { Experience } from "@/components/Experience";
import { Hero } from "@/components/Hero";
import { Navbar } from "@/components/Navbar";
import { Projects } from "@/components/Projects";
import { Skills } from "@/components/Skills";
import { usePortfolioData } from "@/lib/usePortfolioData";

export default function Home() {
  const { data } = usePortfolioData();
  const [themeMode, setThemeMode] = useState<"dark" | "light">("dark");

  useEffect(() => {
    document.documentElement.dataset.theme = themeMode;
  }, [themeMode]);

  if (!data) {
    return null;
  }

  const activeTheme = data.theme[themeMode];

  return (
    <div
      className="min-h-screen transition-colors duration-300"
      style={{
        backgroundColor: activeTheme.backgroundColor,
        color: activeTheme.textColor,
      }}
    >
      <Navbar
        social={data.social}
        themeMode={themeMode}
        onToggleTheme={() =>
          setThemeMode((current) => (current === "dark" ? "light" : "dark"))
        }
        theme={activeTheme}
      />
      <main className="mx-auto flex w-full max-w-7xl flex-col gap-8 px-6 pb-10 lg:px-10">
        <Hero personal={data.personal} theme={activeTheme} />
        <Skills skillDomains={data.skillDomains} theme={activeTheme} />
        <Experience experience={data.experience} />
        <Projects projects={data.projects} theme={activeTheme} />
        <Certifications
          certifications={data.certifications}
          theme={activeTheme}
        />
        <Contact social={data.social} theme={activeTheme} />
      </main>
    </div>
  );
}
