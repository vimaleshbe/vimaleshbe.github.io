<!--
Sync Impact Report
Version change: template -> 1.0.0
Modified principles:
- [PRINCIPLE_1_NAME] -> I. Static Export Compliance
- [PRINCIPLE_2_NAME] -> II. Typed JSON Data Contracts
- [PRINCIPLE_3_NAME] -> III. Strict TypeScript Interfaces
- [PRINCIPLE_4_NAME] -> IV. Tailwind and Motion Discipline
- [PRINCIPLE_5_NAME] -> V. GitHub Pages Deployment Integrity
Expanded sections:
- Implementation Guardrails
- Delivery Workflow
Added sections:
- Implementation Guardrails
- Delivery Workflow
Removed sections:
- None
Templates requiring updates:
- ✅ .specify/templates/plan-template.md
- ✅ .specify/templates/spec-template.md
- ✅ .specify/templates/tasks-template.md
Follow-up TODOs:
- Ensure future spec, plan, and task artifacts keep Jest and minimum coverage guidance aligned
-->

# Vimalesh Portfolio Constitution

## Core Principles

### I. Static Export Compliance

The application MUST remain compatible with static hosting on GitHub Pages at all
times. `next.config.ts` MUST set `output: 'export'`, and proposed changes MUST NOT
introduce server-only rendering, runtime API dependencies, or hosting assumptions that
require a Node.js server. Any exception requires a constitution amendment before code is
merged.

Rationale: The deployment target is a static GitHub Pages site, so static export
compatibility is a non-negotiable delivery constraint rather than an implementation
preference.

### II. Typed JSON Data Contracts

Portfolio content MUST originate from the JSON files in `db/`, and every consumer of
that data MUST treat those files as the source of truth. New data fields, renamed keys,
and structural changes MUST be reflected in explicit TypeScript types before UI code is
updated. Data loading logic MUST preserve build-time compatibility with static export.

Rationale: This project is content-driven. Tight contracts between JSON content and the
UI prevent silent rendering failures and keep the build deterministic.

### III. Strict TypeScript Interfaces

All components, page modules, utilities, and data adapters MUST be implemented in
TypeScript with strict typing enabled. Public props, data models, and helper return
values MUST use explicit interfaces or type aliases when their shape crosses a module
boundary. `any`, untyped props, and shape inference across JSON-driven boundaries MUST
be treated as defects unless a narrow, documented escape hatch is unavoidable.

Rationale: The portfolio is small enough to stay rigorously typed, and strict typing is
the cheapest way to prevent regressions in a statically exported UI.

### IV. Tailwind and Motion Discipline

Styling MUST use Tailwind CSS as the primary presentation layer, and animated UI
behavior MUST use Framer Motion components or helpers instead of ad hoc animation
implementations. New styling work MUST extend the established Tailwind design tokens and
utilities rather than introducing parallel CSS systems, except for global base styles
that Tailwind does not cover cleanly.

Rationale: A single styling system keeps the portfolio maintainable, while a single
animation system keeps motion predictable and reviewable.

### V. GitHub Pages Deployment Integrity

Every feature or refactor MUST preserve a clean static build path suitable for GitHub
Pages publishing. Absolute URLs, asset paths, image handling, and router behavior MUST
be reviewed for static-hosting safety. Documentation and plans MUST call out any change
that affects export behavior, asset resolution, or deployment steps.

Rationale: Static portfolios often fail at deployment boundaries rather than in local
development. This principle forces those risks to be caught during planning and review.

## Implementation Guardrails

- The approved application shape is a Next.js portfolio that renders content from `db/`
  into static pages under `src/pages/`.
- `next.config.ts` MUST enforce `output: 'export'` and MUST be reviewed whenever routing,
  asset prefixes, base paths, or image behavior changes.
- New dependencies MUST be justified against the static-export and client-bundle impact.
- Tailwind CSS and Framer Motion are required platform choices for new visual work. If
  Framer Motion is not yet installed, the implementation plan MUST include adding it
  before shipping motion-heavy UI changes.
- Jest is the approved unit test framework for application code in this repository, and
  feature delivery MUST NOT substitute a different primary unit test runner without a
  constitution amendment.
- API routes, server actions, and any server-only runtime feature are out of bounds
  unless the constitution is amended to change the hosting model.

## Delivery Workflow

- Every spec and implementation plan MUST include a constitution check that verifies
  static export compatibility, typed JSON contracts, strict TypeScript interfaces, and
  Tailwind plus Framer Motion usage for UI work.
- Every task list MUST include explicit work for validating `db/` schema usage, typed
  data models, Jest-based unit coverage for the implemented UI and data layer, and a
  production static build before completion.
- Feature completion MUST fail validation when enforced overall code coverage drops below
  85%.
- Pull requests and reviews MUST reject changes that weaken typing, bypass JSON source
  data, or introduce non-static deployment assumptions.
- README and related runtime guidance MUST stay aligned with the GitHub Pages deployment
  model and the active frontend stack.

## Governance

This constitution overrides conflicting local practices for this repository. Amendments
MUST be documented in `.specify/memory/constitution.md`, include an explicit rationale,
and update any affected templates or workflow guidance in the same change. Versioning
follows semantic rules for governance documents: MAJOR for incompatible principle
changes or removals, MINOR for new principles or materially expanded governance, and
PATCH for clarifications that do not change required behavior. Compliance review is
mandatory for every spec, plan, task list, and pull request touching application or
deployment behavior.

**Version**: 1.1.0 | **Ratified**: 2026-08-09 | **Last Amended**: 2026-08-09
