# Vimalesh Portfolio

Static portfolio site built with Next.js Pages Router, TypeScript, Tailwind CSS, Framer Motion, and TanStack Query. All rendered content is sourced from JSON files in `db/` and exported for GitHub Pages deployment.

## Stack

- Next.js 16 Pages Router with `output: "export"`
- TypeScript with strict interfaces
- Tailwind CSS v4 for styling
- Framer Motion for section animations with reduced-motion support
- TanStack Query for the normalized portfolio data hook
- Jest and Testing Library for component and page validation

## Data Sources

The homepage is composed from these JSON files under `db/`:

- `personal.json`
- `skills.json`
- `experience.json`
- `projects.json`
- `certification.json`
- `education.json`
- `social.json`
- `theme.json`

Shared contracts live in `src/types/portfolio.ts`, and normalization is handled in `src/lib/usePortfolioData.ts`.

## Local Development

Install dependencies:

```bash
npm install
```

If your global npm cache has permission issues, use a local cache:

```bash
npm_config_cache=$PWD/.npm-cache npm install
```

Start the development server:

```bash
npm run dev
```

Open `http://localhost:3000` to inspect the portfolio locally.

## Validation Commands

Run lint:

```bash
npm run lint
```

Run the Jest suite with coverage:

```bash
npm test -- --runInBand
```

Coverage enforcement is feature-required. The test configuration fails validation if overall coverage drops below 85%.

Current verified result:

- Statements: 100%
- Branches: 96.77%
- Functions: 100%
- Lines: 100%

Coverage scope includes:

- Section components in `src/components/`
- The shared data layer in `src/lib/usePortfolioData.ts`
- Navbar interaction behavior
- The composed homepage flow in `src/pages/index.tsx`

The current refinement also validates:

- Theme switching between dark and light palettes sourced from `db/theme.json`
- Opaque navbar behavior during scroll
- Navbar icon rendering from local assets in `public/`
- Hero simplification, profile image rendering, and first-screen fit
- Full-width horizontal Current Focus metrics in the hero card
- Timeline rendering in the experience section
- Certification footer alignment, including consistent divider and footer starting position across cards with different wrapping
- Embedded contact actions without visible raw identifiers
- Light-theme readability across capabilities, projects, certifications, experience, and contact sections

Run the production build:

```bash
npm run build
```

For the `002-portfolio-refinement` feature, the feature-specific validation guide is in `specs/002-portfolio-refinement/quickstart.md`.

## Deployment

GitHub Pages deployment is defined in `.github/workflows/deploy.yml`.

The workflow performs:

1. `npm ci`
2. `npm run lint`
3. `npm test -- --runInBand`
4. `npm run build`
5. Upload of the `out/` static export artifact
6. Deployment to GitHub Pages

## Notes

- The app is intentionally static-export only and does not use API routes.
- `next.config.ts` must keep `output: "export"` and `images.unoptimized: true` for Pages compatibility.
- If `npm run build` fails in a restricted sandbox, rerun it outside the sandbox before treating the app as broken; prior build failures in this workspace were caused by Turbopack process restrictions rather than application code errors.
