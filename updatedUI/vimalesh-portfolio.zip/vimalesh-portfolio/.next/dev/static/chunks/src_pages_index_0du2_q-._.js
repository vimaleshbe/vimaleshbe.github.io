(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__14gz0ua._.js","static/chunks/node_modules_next_dist_compiled_0kw0nba._.js","static/chunks/node_modules_next_dist_shared_lib_0o5unhj._.js","static/chunks/node_modules_next_dist_client_1oox48h._.js","static/chunks/node_modules_next_dist_0zk-zb1._.js","static/chunks/node_modules_next_image_1w1vmoh.js","static/chunks/node_modules_react-dom_0kla17-._.js","static/chunks/node_modules_motion-dom_dist_es_11wbjiv._.js","static/chunks/node_modules_framer-motion_dist_es_1wuuabx._.js","static/chunks/node_modules_20b2m_h._.js"],
    source: "entry"
});
