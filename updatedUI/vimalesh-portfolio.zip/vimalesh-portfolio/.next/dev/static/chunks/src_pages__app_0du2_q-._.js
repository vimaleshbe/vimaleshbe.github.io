(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_compiled_14ibvna._.js","static/chunks/node_modules_next_dist_shared_lib_196_nl_._.js","static/chunks/node_modules_next_dist_client_16lnmlo._.js","static/chunks/node_modules_next_dist_0zk-zb1._.js","static/chunks/node_modules_react-dom_0kla17-._.js","static/chunks/node_modules_0y6jgwd._.js","static/chunks/[root-of-the-server]__04ty7pw._.js","static/chunks/src_styles_globals_0rqpain.css"],
    source: "entry"
});
