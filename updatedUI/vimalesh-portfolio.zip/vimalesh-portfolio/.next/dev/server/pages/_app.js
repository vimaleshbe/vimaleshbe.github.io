var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__0il6x8z._.js")
R.m("[project]/src/pages/_app.tsx [ssr] (ecmascript)")
module.exports=R.m("[project]/src/pages/_app.tsx [ssr] (ecmascript)").exports
